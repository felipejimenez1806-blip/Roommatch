<?php

namespace Database\Seeders;

use Database\Seeders\AdminUsuarioSeeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RolSeeder::class,
            AdminUsuarioSeeder::class,
        ]);
    }
}
