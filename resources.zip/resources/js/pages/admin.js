// ============================================================
// ROOMMATCH – PANEL DE ADMINISTRACIÓN (migrado a la API real)
// ------------------------------------------------------------
// Cubre HU-11 (usuarios), HU-12 (publicaciones) y HU-13 (reportes),
// consumiendo /api/admin/* en vez de localStorage. Mismo patrón de
// autenticación que perfil.js (sesión manejada por core/auth.js).
//
// La protección real de "solo admin" vive en el servidor
// (middleware es.admin sobre /api/admin/*). Aquí solo se evita
// mostrar el panel a quien no sea admin, igual que hacía la versión
// anterior con el usuario sembrado en localStorage.
//
// CAMBIO (roles N:N, Fase 1-3): tipo_usuario (ENUM) ya no existe.
// Usuario::paraFrontend() ahora manda 'roles' (arreglo, ej. ["cliente"]
// o ["cliente","admin"]) en vez de 'tipoUsuario', así que el guard de
// acceso de abajo se actualizó para leer ese arreglo. La TABLA de
// usuarios sigue trayendo 'tipoUsuario' desde el backend (ver
// Admin\UsuarioController::paraTablaAdmin()) — es un shim transicional
// que prioriza "admin" si el usuario tiene ambos roles, mientras no se
// rediseñe esta vista para pintar los dos badges a la vez (Fase 4).
//
// CAMBIO (soft delete): las publicaciones ya no se borran físicamente
// (ver App\Models\Publicacion::SoftDeletes). El panel de Publicaciones
// ahora deja ver "Activas" (default), "Eliminadas" y "Todas", y permite
// restaurar una eliminada — útil si un admin la borró por error o si
// tras revisar un reporte se concluye que no incumplía nada.
// ============================================================

import { API_BASE } from "../core/config.js";
import { requerirSesion, obtenerUsuario, cabecerasAutenticadas, manejarNoAutorizado as manejarSesionInvalida } from "../core/auth.js";
import { selectHtml, enlazarSelects, valorSelect } from "../core/select-personalizado.js";

requerirSesion({ rol: "admin" });
const usuarioActual = obtenerUsuario();
// Superadmin (cuenta admin @roommatch.com creada por seeder o por otro superadmin):
// único que puede bloquear/desbloquear administradores. Solo afecta qué botones se
// muestran; el servidor valida cada acción.
const soySuperadmin = Boolean(usuarioActual?.esSuperadmin);

// En el panel admin un 403 (la cuenta perdió el rol) también expulsa al dashboard.
function manejarNoAutorizado(respuesta) {
  return manejarSesionInvalida(respuesta, { redirigir403: true });
}

document.getElementById("admLogoutBtn").addEventListener("click", () => {
  window.RoommatchNav.cerrarSesion();
});

// ------------------------------------------------------------
// Helpers de la Fase "moderador"
// ------------------------------------------------------------

// Todo texto que escribe un usuario y se pinta con innerHTML debe pasar por
// esc(). Aquí se aplica en las secciones de Reportes, Mensajes y Auditoría.
function esc(valor) {
  return String(valor ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Petición para ACCIONES (resolver, escalar, responder...). A diferencia del
// manejarNoAutorizado de arriba, un 403 NO expulsa al dashboard: ahora una
// Policy puede negar una acción concreta (p. ej. "este reporte ya fue
// gestionado") sin que la cuenta haya perdido el rol; se muestra su mensaje.
// Devuelve { ok, status, datos } o null si la sesión venció.
async function peticionAccion(ruta, { metodo = "PATCH", cuerpo } = {}) {
  const respuesta = await fetch(`${API_BASE}${ruta}`, {
    method: metodo,
    credentials: "same-origin",
    headers: cabecerasAutenticadas(cuerpo !== undefined),
    ...(cuerpo !== undefined ? { body: JSON.stringify(cuerpo) } : {}),
  });
  if (manejarSesionInvalida(respuesta)) return null;
  const datos = await respuesta.json().catch(() => ({}));
  return { ok: respuesta.ok, status: respuesta.status, datos };
}

function textoError(res, porDefecto) {
  if (res?.datos?.errors) {
    const primero = Object.values(res.datos.errors)[0];
    if (Array.isArray(primero) && primero[0]) return primero[0];
  }
  return res?.datos?.mensaje || res?.datos?.message || porDefecto;
}

// ============================================================
// "USAR TAMBIÉN COMO CLIENTE" (Fase 4 - ajuste)
// ------------------------------------------------------------
// El botón equivalente en nav.js pinta dentro de #navActions, que NO
// existe en layouts.admin — y un admin puro nunca puede salir de
// /admin para verlo en una página con layouts.app (el middleware
// zona.cliente lo rebota de vuelta). Así que aquí, en el panel mismo, se inyecta un
// botón junto al de "Cerrar sesión" (reutiliza su misma clase CSS,
// sea cual sea, para no depender de estilos que no están en admin.css)
// y reusa el modal ya construido en nav.js vía window.RoommatchNav.
// ============================================================
function inicializarUsarComoClienteAdmin() {
  // Un superadmin solo puede ejercer el rol de administrador.
  if (soySuperadmin) return;
  const roles = usuarioActual.roles || [];
  const esSoloAdmin = roles.includes("admin") && !roles.includes("cliente");
  if (!esSoloAdmin) return;

  const logoutBtn = document.getElementById("admLogoutBtn");
  if (!logoutBtn || !window.RoommatchNav?.abrirModalUsarComoCliente) return;

  const btn = document.createElement("button");
  btn.type = "button";
  btn.id = "admUsarClienteBtn";
  btn.className = logoutBtn.className;
  // Ícono de usuario con "+" (agregar el rol de cliente), mismo estilo que el resto del panel.
  btn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6"/><path d="M22 11h-6"/></svg>Usar también como cliente`;
  btn.style.marginBottom = "8px";

  logoutBtn.insertAdjacentElement("beforebegin", btn);
  btn.addEventListener("click", () => window.RoommatchNav.abrirModalUsarComoCliente());
}
inicializarUsarComoClienteAdmin();

// "Cambiar de rol" (Ingresar como…) para quien tiene más de un rol: el
// navbar de cliente no existe en /admin, así que se inyecta aquí y se
// reutiliza el modal de nav.js (pide contraseña al pasar a moderador).
function inicializarCambiarRolAdmin() {
  if ((usuarioActual.roles || []).length < 2) return;

  const logoutBtn = document.getElementById("admLogoutBtn");
  if (!logoutBtn || !window.RoommatchNav?.abrirModalCambiarRol) return;

  const btn = document.createElement("button");
  btn.type = "button";
  btn.id = "admCambiarRolBtn";
  btn.className = logoutBtn.className;
  // Mismo ícono (flechas de intercambio) que el botón del panel de moderación.
  btn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>Cambiar de rol`;
  btn.style.marginBottom = "8px";

  logoutBtn.insertAdjacentElement("beforebegin", btn);
  btn.addEventListener("click", () => window.RoommatchNav.abrirModalCambiarRol());
}
inicializarCambiarRolAdmin();

// ============================================================
// HELPERS GENERALES
// ============================================================
function formatCOP(n) {
  return "$" + Math.round(n).toLocaleString("es-CO") + " COP";
}
function formatFecha(iso) {
  if (!iso) return "Sin fecha";
  return new Date(iso).toLocaleDateString("es-CO", { day: "2-digit", month: "short", year: "numeric" });
}
function inicial(nombre) {
  return (nombre || "U").trim().charAt(0).toUpperCase();
}
function mostrarToast(mensaje) {
  const toast = document.getElementById("admToast");
  toast.textContent = mensaje;
  toast.classList.add("show");
  clearTimeout(mostrarToast._t);
  mostrarToast._t = setTimeout(() => toast.classList.remove("show"), 2200);
}
function abrirModal(html) {
  document.getElementById("admModal").innerHTML = html;
  document.getElementById("admModalOverlay").hidden = false;
}
function cerrarModal() {
  document.getElementById("admModalOverlay").hidden = true;
  document.getElementById("admModal").innerHTML = "";
}
document.getElementById("admModalOverlay").addEventListener("click", (e) => {
  if (e.target.id === "admModalOverlay") cerrarModal();
});
function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

// ============================================================
// NAVEGACIÓN ENTRE SECCIONES (sidebar)
// ============================================================
document.querySelectorAll("#admNav .prf-nav-item").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("#admNav .prf-nav-item").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".prf-panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.panel).classList.add("active");
  });
});

function activarPanelPorHash() {
  const panelId = window.location.hash.replace("#", "");
  if (!panelId) return;
  const btn = document.querySelector(`#admNav .prf-nav-item[data-panel="${panelId}"]`);
  if (btn) btn.click();
}
window.addEventListener("hashchange", activarPanelPorHash);

// ============================================================
// USUARIOS (HU-11)
// ============================================================
// Roles que el panel muestra (de menor a mayor privilegio) y los que un
// administrador puede asignar/quitar. 'cliente' no se promueve ni se revoca
// desde aquí (todo el que se registra ya lo es).
const ORDEN_ROLES = ["cliente", "moderador", "admin"];
const ROLES_EQUIPO = ["moderador", "admin"];
const ETIQUETA_ROL = { cliente: "Cliente", moderador: "Moderador", admin: "Administrador" };

let filtroUsuarioActual = "todos";
let busquedaUsuarioActual = "";

async function renderUsuarios() {
  const body = document.getElementById("admUsuariosBody");
  const empty = document.getElementById("admUsuariosEmpty");
  const tabla = document.getElementById("admUsuariosTabla");

  const params = new URLSearchParams({ filtro: filtroUsuarioActual });
  if (busquedaUsuarioActual) params.set("q", busquedaUsuarioActual);

  const respuesta = await fetch(`${API_BASE}/admin/usuarios?${params}`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await respuesta.json();
  const lista = datos.usuarios || [];

  if (!lista.length) {
    tabla.hidden = true;
    empty.hidden = false;
    empty.textContent = busquedaUsuarioActual || filtroUsuarioActual !== "todos"
      ? "No hay usuarios que coincidan con la búsqueda o el filtro."
      : "Aún no hay usuarios registrados.";
    return;
  }
  tabla.hidden = false;
  empty.hidden = true;

  body.innerHTML = lista.map((u) => {
    const avatar = u.fotoPerfil ? `<img src="${esc(u.fotoPerfil)}" alt="${esc(u.nombre)}"/>` : esc(inicial(u.nombre));
    const roles = u.roles || [];
    const esAdmin = roles.includes("admin");
    const esSuperadminFila = Boolean(u.esSuperadmin);
    const nombreAttr = esc(u.nombre);

    // Una cuenta puede tener varios roles a la vez: se pintan en una sola
    // línea, de menor a mayor privilegio (Cliente / Moderador / Administrador).
    const badgesRol = ORDEN_ROLES
      .filter((r) => roles.includes(r))
      .map((r) => (r === "admin" && esSuperadminFila
        ? `<span class="adm-tipo-badge is-superadmin">Superadmin</span>`
        : `<span class="adm-tipo-badge is-${r}">${ETIQUETA_ROL[r]}</span>`))
      .join(`<span class="adm-roles-sep" aria-hidden="true">/</span>`);

    // Un solo botón "Promover" y un solo "Revocar": el rol concreto se elige
    // en el modal. Cada botón solo aparece si hay algo que hacer (roles de
    // equipo que la cuenta aún no tiene / que ya tiene). El servidor vuelve
    // a validar todo en cada ruta (can:gestionar-roles, cuenta de sistema,
    // auto-revocación).
    // Sin Promover ni Revocar en la fila de un superadmin (sus roles no se
    // modifican) ni en la propia (nadie cambia sus propios roles: lo hace otro
    // administrador).
    const sinCambioDeRoles = esSuperadminFila || u.id === usuarioActual.id;
    const rolesPromovibles = sinCambioDeRoles ? [] : ROLES_EQUIPO.filter((r) => !roles.includes(r));
    const rolesRevocables = sinCambioDeRoles ? [] : ROLES_EQUIPO.filter((r) => roles.includes(r));

    const botonPromover = rolesPromovibles.length
      ? `<button type="button" class="adm-row-btn" data-promover="${u.id}" data-roles="${rolesPromovibles.join(",")}" data-nombre="${nombreAttr}">Promover</button>`
      : "";
    const botonRevocar = rolesRevocables.length
      ? `<button type="button" class="adm-row-btn is-danger" data-revocar="${u.id}" data-roles="${rolesRevocables.join(",")}" data-nombre="${nombreAttr}">Revocar</button>`
      : "";
    // Bloquear/desbloquear una cuenta que no es admin: como siempre. Una cuenta
    // admin (superadmin o no) solo la bloquea un superadmin, y nunca a sí mismo
    // (ver UsuarioController::bloquear).
    const puedeBloquear = !esAdmin || (soySuperadmin && u.id !== usuarioActual.id);
    const botonBloqueo = !puedeBloquear
      ? ""
      : `<button type="button" class="adm-row-btn ${u.bloqueado ? "" : "is-danger"}" data-toggle-bloqueo="${u.id}" data-bloqueado="${u.bloqueado}" data-nombre="${nombreAttr}">
           ${u.bloqueado ? "Desbloquear" : "Bloquear"}
         </button>`;

    const accionesHtml = `${botonPromover}${botonRevocar}${botonBloqueo}`;

    return `
      <tr>
        <td data-label="Usuario">
          <div class="adm-user-cell">
            <span class="adm-user-avatar">${avatar}</span>
            <span class="adm-user-name">${esc(u.nombre || "Sin nombre")}</span>
          </div>
        </td>
        <td data-label="Correo">${esc(u.email || "—")}</td>
        <td data-label="Tipo"><div class="adm-roles">${badgesRol}</div></td>
        <td data-label="Teléfono">${esc(u.telefono || "—")}</td>
        <td data-label="Estado">
          <span class="prf-badge ${u.bloqueado ? "is-bloqueado" : "is-activo"}">${u.bloqueado ? "Bloqueado" : "Activo"}</span>
        </td>
        <td data-label="">
          <div class="adm-row-actions">
            ${accionesHtml}
          </div>
        </td>
      </tr>`;
  }).join("");

  body.querySelectorAll("[data-toggle-bloqueo]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = Number(btn.dataset.toggleBloqueo);
      const bloqueado = btn.dataset.bloqueado === "true";
      bloqueado ? desbloquearUsuario(id, btn.dataset.nombre) : abrirModalBloqueo(id, btn.dataset.nombre);
    });
  });
  body.querySelectorAll("[data-promover]").forEach((btn) => {
    btn.addEventListener("click", () => {
      abrirModalPromover(Number(btn.dataset.promover), btn.dataset.nombre, btn.dataset.roles.split(","));
    });
  });
  body.querySelectorAll("[data-revocar]").forEach((btn) => {
    btn.addEventListener("click", () => {
      abrirModalRevocar(Number(btn.dataset.revocar), btn.dataset.nombre, btn.dataset.roles.split(","));
    });
  });
}

async function desbloquearUsuario(id, nombre) {
  const res = await peticionAccion(`/admin/usuarios/${id}/desbloquear`);
  if (!res) return;
  mostrarToast(res.ok ? (res.datos.mensaje || `${nombre} fue desbloqueado.`) : textoError(res, "No se pudo desbloquear la cuenta."));
  renderUsuarios();
  renderResumen();
  renderAuditoria();
}

function abrirModalBloqueo(id, nombre) {
  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">Bloquear a ${esc(nombre)}</p>
    <textarea class="adm-modal-textarea" id="admMotivoBloqueo" placeholder="Motivo del bloqueo (ej. incumplimiento de las normas de la comunidad)..."></textarea>
    <p class="adm-modal-error" id="admBloqueoError"></p>
    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCancelarBloqueo">Cancelar</button>
      <button type="button" class="adm-row-btn is-danger" id="admConfirmarBloqueo">Bloquear usuario</button>
    </div>
  `);
  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCancelarBloqueo").addEventListener("click", cerrarModal);
  document.getElementById("admConfirmarBloqueo").addEventListener("click", async () => {
    const motivo = document.getElementById("admMotivoBloqueo").value.trim();
    const res = await peticionAccion(`/admin/usuarios/${id}/bloquear`, { cuerpo: { motivo } });
    if (!res) return;
    if (!res.ok) {
      // Los resguardos del servidor (solo superadmin, no a sí mismo) se muestran en el modal.
      document.getElementById("admBloqueoError").textContent = textoError(res, "No se pudo bloquear la cuenta.");
      return;
    }
    cerrarModal();
    mostrarToast(res.datos.mensaje || `${nombre} fue bloqueado.`);
    renderUsuarios();
    renderResumen();
    renderAuditoria();
  });
}

// ---------- Promover / revocar rol (admin o moderador) ----------
// Un solo flujo para ambos roles: el modal muestra un select con los roles
// que aplican a esa cuenta y, según la elección, llama a la ruta de siempre
// (promover-admin / promover-moderador / revocar-admin / revocar-moderador).

const DESCRIPCION_PROMOVER = {
  admin: "Tendrá acceso completo al panel de administración. Conserva sus demás roles.",
  moderador: "Podrá resolver reportes, bajar publicaciones y responder mensajes de contacto desde su propio panel. No podrá bloquear usuarios ni asignar roles. Conserva sus demás roles.",
};
const DESCRIPCION_REVOCAR = {
  admin: "Dejará de tener acceso al panel de administración. Sus demás roles no cambian.",
  moderador: "Dejará de tener acceso al panel de moderación. Sus demás roles no cambian.",
};

function opcionesDeRoles(roles) {
  return roles.map((r) => [r, ETIQUETA_ROL[r]]);
}

function abrirModalPromover(id, nombre, rolesDisponibles) {
  const opciones = opcionesDeRoles(rolesDisponibles);
  // Con una sola opción posible (ya tiene el otro rol) llega preseleccionada.
  const inicial = opciones.length === 1 ? opciones[0][0] : "";

  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">Promover a ${esc(nombre)}</p>
    <p class="adm-modal-sub" id="admPromoverDescripcion">${esc(DESCRIPCION_PROMOVER[inicial] || "Elige el rol que tendrá esta cuenta. Confirma tu contraseña para autorizar la acción.")}</p>

    <label class="adm-modal-label" id="admPromoverRolLabel">Promover a</label>
    ${selectHtml({ id: "admPromoverRol", opciones, valor: inicial, placeholder: "Selecciona un rol", labelledby: "admPromoverRolLabel" })}

    <label class="adm-modal-label" for="admPasswordPromover">Tu contraseña actual</label>
    <!-- new-password + readonly hasta enfocar: evita que el navegador trate este
         campo como un login y rellene "usuario" en el buscador de la página. -->
    <input type="password" class="adm-modal-input" id="admPasswordPromover" name="adm_confirmar_password_propia" placeholder="Confirma tu contraseña" autocomplete="new-password" readonly onfocus="this.removeAttribute('readonly')"/>
    <p class="adm-modal-error" id="admPromoverError"></p>

    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCancelarPromover">Cancelar</button>
      <button type="button" class="adm-row-btn is-primary" id="admConfirmarPromover">Promover</button>
    </div>
  `);

  const selectEl = document.getElementById("admPromoverRol");
  const errorEl = document.getElementById("admPromoverError");
  enlazarSelects(document.getElementById("admModal"));

  selectEl.addEventListener("select-cambio", (e) => {
    selectEl.classList.remove("has-error");
    errorEl.textContent = "";
    document.getElementById("admPromoverDescripcion").textContent = DESCRIPCION_PROMOVER[e.detail.valor] || "";
  });

  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCancelarPromover").addEventListener("click", cerrarModal);
  document.getElementById("admConfirmarPromover").addEventListener("click", async () => {
    const rol = valorSelect(selectEl);
    if (!rol) {
      selectEl.classList.add("has-error");
      errorEl.textContent = "Selecciona a qué rol promover.";
      return;
    }

    const res = await peticionAccion(`/admin/usuarios/${id}/promover-${rol === "admin" ? "admin" : "moderador"}`, {
      cuerpo: { password_actual: document.getElementById("admPasswordPromover").value },
    });
    if (!res) return;
    if (!res.ok) {
      errorEl.textContent = textoError(res, "No se pudo promover al usuario.");
      return;
    }

    cerrarModal();
    mostrarToast(res.datos.mensaje || `${nombre} ahora es ${ETIQUETA_ROL[rol].toLowerCase()}.`);
    renderUsuarios();
    renderResumen();
    renderAuditoria();
  });
}

function abrirModalRevocar(id, nombre, rolesDisponibles) {
  const opciones = opcionesDeRoles(rolesDisponibles);
  const inicial = opciones.length === 1 ? opciones[0][0] : "";

  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">Revocar rol a ${esc(nombre)}</p>
    <p class="adm-modal-sub" id="admRevocarDescripcion">${esc(DESCRIPCION_REVOCAR[inicial] || "Elige el rol que se le quitará a esta cuenta.")}</p>

    <label class="adm-modal-label" id="admRevocarRolLabel">Revocar el rol de</label>
    ${selectHtml({ id: "admRevocarRol", opciones, valor: inicial, placeholder: "Selecciona un rol", labelledby: "admRevocarRolLabel" })}
    <p class="adm-modal-error" id="admRevocarError"></p>

    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCancelarRevocar">Cancelar</button>
      <button type="button" class="adm-row-btn is-danger" id="admConfirmarRevocar">Revocar</button>
    </div>
  `);

  const selectEl = document.getElementById("admRevocarRol");
  const errorEl = document.getElementById("admRevocarError");
  enlazarSelects(document.getElementById("admModal"));

  selectEl.addEventListener("select-cambio", (e) => {
    selectEl.classList.remove("has-error");
    errorEl.textContent = "";
    document.getElementById("admRevocarDescripcion").textContent = DESCRIPCION_REVOCAR[e.detail.valor] || "";
  });

  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCancelarRevocar").addEventListener("click", cerrarModal);
  document.getElementById("admConfirmarRevocar").addEventListener("click", async () => {
    const rol = valorSelect(selectEl);
    if (!rol) {
      selectEl.classList.add("has-error");
      errorEl.textContent = "Selecciona qué rol revocar.";
      return;
    }

    const res = await peticionAccion(`/admin/usuarios/${id}/revocar-${rol === "admin" ? "admin" : "moderador"}`);
    if (!res) return;
    if (!res.ok) {
      // Los resguardos del servidor (cuenta de sistema, auto-revocación)
      // se muestran dentro del modal para que se pueda elegir otro rol.
      errorEl.textContent = textoError(res, "No se pudo revocar el rol.");
      return;
    }

    cerrarModal();
    mostrarToast(res.datos.mensaje || `Se revocó el rol de ${ETIQUETA_ROL[rol].toLowerCase()} a ${nombre}.`);
    renderUsuarios();
    renderResumen();
    renderAuditoria();
  });
}

function inicializarUsuarios() {
  document.getElementById("admUsuariosSearch").addEventListener("input", debounce((e) => {
    busquedaUsuarioActual = e.target.value.trim();
    renderUsuarios();
  }, 300));
  document.querySelectorAll("#admUsuariosFiltros .prf-subtab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#admUsuariosFiltros .prf-subtab").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      filtroUsuarioActual = btn.dataset.filtro;
      renderUsuarios();
    });
  });
  renderUsuarios();
}

// ============================================================
// PUBLICACIONES (HU-12)
// ============================================================
let busquedaPubActual = "";
let filtroPubActual = "activas"; // 'activas' | 'eliminadas' | 'todas' — ver Admin\PublicacionController::index()

async function renderPublicaciones() {
  const grid = document.getElementById("admPubsGrid");
  const empty = document.getElementById("admPubsEmpty");

  const params = new URLSearchParams({ estado: filtroPubActual });
  if (busquedaPubActual) params.set("q", busquedaPubActual);

  const respuesta = await fetch(`${API_BASE}/admin/publicaciones?${params}`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await respuesta.json();
  const lista = datos.publicaciones || [];

  if (!lista.length) {
    grid.innerHTML = "";
    empty.hidden = false;
    empty.textContent = filtroPubActual === "eliminadas"
      ? "No hay publicaciones eliminadas."
      : "No se encontraron publicaciones.";
    return;
  }
  empty.hidden = true;

  grid.innerHTML = lista.map((p) => `
    <div class="adm-pub-card">
      <img class="adm-pub-img" src="${esc(p.img || "")}" alt="${esc(p.titulo)}"/>
      <div class="adm-pub-body">
        <div class="adm-pub-title">
          ${esc(p.titulo)}
          ${p.eliminada ? `<span class="prf-badge is-bloqueado" style="margin-left:6px;">Eliminada</span>` : ""}
        </div>
        <div class="adm-pub-sub">${esc(p.zona)} · ${esc(p.ciudad)} · ★ ${esc(p.rating ?? "—")}</div>
        <div class="adm-pub-price">${formatCOP(p.precio)}</div>
        <div class="adm-pub-owner">Propietario: ${esc(p.propietario || "—")}</div>
        <div class="adm-pub-actions">
          ${p.eliminada
            ? `<button type="button" class="adm-row-btn is-primary" data-restaurar-pub="${esc(p.id)}">Restaurar</button>`
            : `<button type="button" class="adm-row-btn" data-ver-pub="${esc(p.id)}">Ver detalle</button>
               <button type="button" class="adm-row-btn is-danger" data-eliminar-pub="${esc(p.id)}" data-titulo="${esc(p.titulo)}">Eliminar</button>`}
        </div>
      </div>
    </div>`).join("");

  grid.querySelectorAll("[data-ver-pub]").forEach((btn) => {
    btn.addEventListener("click", () => abrirModalPublicacion(Number(btn.dataset.verPub)));
  });
  grid.querySelectorAll("[data-eliminar-pub]").forEach((btn) => {
    btn.addEventListener("click", () => confirmarEliminarPublicacion(Number(btn.dataset.eliminarPub), btn.dataset.titulo));
  });
  grid.querySelectorAll("[data-restaurar-pub]").forEach((btn) => {
    btn.addEventListener("click", () => restaurarPublicacion(Number(btn.dataset.restaurarPub)));
  });
}

async function restaurarPublicacion(id) {
  const respuesta = await fetch(`${API_BASE}/admin/publicaciones/${id}/restaurar`, { method: "PATCH", headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  if (!respuesta.ok) {
    mostrarToast("No se pudo restaurar la publicación.");
    return;
  }
  mostrarToast("Publicación restaurada.");
  renderPublicaciones();
  renderResumen();
}

// Reutiliza el endpoint público GET /api/publicaciones/{id}: ya trae
// características, propietario y reseñas formateadas, y no requiere
// duplicar ese formateo en el controlador de admin. Solo aplica a
// publicaciones activas (una eliminada no tiene botón "Ver detalle").
async function abrirModalPublicacion(id) {
  const respuesta = await fetch(`${API_BASE}/publicaciones/${id}`, { headers: cabecerasAutenticadas(false) });
  if (!respuesta.ok) return;
  const { publicacion: p } = await respuesta.json();
  const c = p.caracteristicas || {};

  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">${esc(p.titulo)}</p>
    <p class="adm-modal-sub">${esc(p.direccion || "")} · ${esc(p.zona)}, ${esc(p.ciudad)}</p>
    <img class="adm-modal-img" src="${esc((p.imagenes && p.imagenes[0]) || "")}" alt="${esc(p.titulo)}"/>
    <dl class="adm-modal-grid">
      <dt>Precio</dt><dd>${formatCOP(p.precio)}</dd>
      <dt>Tipo de espacio</dt><dd>${esc(p.tipo_espacio || "—")}</dd>
      <dt>Propietario</dt><dd>${esc(p.propietario?.nombre || "—")}</dd>
      <dt>Correo</dt><dd>${esc(p.propietario?.correo || "—")}</dd>
      <dt>Rating</dt><dd>★ ${esc(p.rating ?? "—")} (${esc((p.resenas || []).length)} reseñas)</dd>
      <dt>Disponible desde</dt><dd>${esc(p.fecha_disponible || "—")}</dd>
      <dt>Amueblado</dt><dd>${esc(c.amueblado ? "Sí" : "No")}</dd>
      <dt>Baño privado</dt><dd>${esc(c.bano_privado ? "Sí" : "No")}</dd>
      <dt>Ambiente</dt><dd>${esc(c.ambiente_hogar || "—")}</dd>
      <dt>Nº habitantes</dt><dd>${esc(c.numero_habitantes ?? "—")}</dd>
    </dl>
    <p style="font-size:13.5px;color:#555;line-height:1.5;margin:0 0 18px;">${esc(p.descripcion || "")}</p>
    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCerrarDetallePub">Cerrar</button>
      <button type="button" class="adm-row-btn is-danger" id="admEliminarDesdeModal">Eliminar publicación</button>
    </div>
  `);
  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCerrarDetallePub").addEventListener("click", cerrarModal);
  document.getElementById("admEliminarDesdeModal").addEventListener("click", () => {
    cerrarModal();
    confirmarEliminarPublicacion(p.id, p.titulo);
  });
}

function confirmarEliminarPublicacion(id, titulo) {
  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">¿Eliminar esta publicación?</p>
    <p class="adm-modal-sub">"${esc(titulo)}" dejará de verse en el sitio y el propietario recibirá una notificación. El registro no se borra de la base de datos: puedes restaurarla después desde el filtro "Eliminadas" si fue un error.</p>
    <textarea class="adm-modal-textarea" id="admMotivoEliminarPub" maxlength="255" placeholder="Motivo (opcional). Lo verá el propietario y queda en la auditoría."></textarea>
    <p class="adm-modal-sub" id="admEliminarPubError" style="color:#c0261c;min-height:15px;margin-top:-6px;"></p>
    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCancelarEliminarPub">Cancelar</button>
      <button type="button" class="adm-row-btn is-danger" id="admConfirmarEliminarPub">Sí, eliminar</button>
    </div>
  `);
  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCancelarEliminarPub").addEventListener("click", cerrarModal);
  document.getElementById("admConfirmarEliminarPub").addEventListener("click", async () => {
    const motivo = document.getElementById("admMotivoEliminarPub").value.trim();
    const res = await peticionAccion(`/admin/publicaciones/${id}`, {
      metodo: "DELETE",
      cuerpo: motivo ? { motivo } : {},
    });
    if (!res) return;
    if (!res.ok) {
      document.getElementById("admEliminarPubError").textContent = textoError(res, "No se pudo eliminar la publicación.");
      return;
    }
    cerrarModal();
    mostrarToast("Publicación eliminada.");
    renderPublicaciones();
    renderResumen();
    renderReportes();
    renderAuditoria();
  });
}

function inicializarPublicaciones() {
  document.getElementById("admPubsSearch").addEventListener("input", debounce((e) => {
    busquedaPubActual = e.target.value.trim();
    renderPublicaciones();
  }, 300));

  document.querySelectorAll("#admPubsFiltros .prf-subtab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#admPubsFiltros .prf-subtab").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      filtroPubActual = btn.dataset.filtro;
      renderPublicaciones();
    });
  });

  renderPublicaciones();
}

// ============================================================
// ROOMIES
// ------------------------------------------------------------
// Mismo patrón que Publicaciones (HU-12): activos/eliminados/todos +
// restaurar, reutilizando las mismas clases .adm-pub-* del CSS (son
// genéricas: título, subtítulo, precio, dueño, acciones) para no
// duplicar estilos.
// ============================================================
let busquedaRoomieActual = "";
let filtroRoomieActual = "activos"; // 'activos' | 'eliminados' | 'todos' — ver Admin\PersonaRoomieController::index()

async function renderRoomies() {
  const grid = document.getElementById("admRoomiesGrid");
  const empty = document.getElementById("admRoomiesEmpty");

  const params = new URLSearchParams({ estado: filtroRoomieActual });
  if (busquedaRoomieActual) params.set("q", busquedaRoomieActual);

  const respuesta = await fetch(`${API_BASE}/admin/roomies?${params}`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await respuesta.json();
  const lista = datos.personas || [];

  if (!lista.length) {
    grid.innerHTML = "";
    empty.hidden = false;
    empty.textContent = filtroRoomieActual === "eliminados"
      ? "No hay perfiles de roomie eliminados."
      : "No se encontraron perfiles de roomie.";
    return;
  }
  empty.hidden = true;

  grid.innerHTML = lista.map((p) => `
    <div class="adm-pub-card">
      <img class="adm-pub-img" src="${esc(p.img || "")}" alt="${esc(p.nombre)}"/>
      <div class="adm-pub-body">
        <div class="adm-pub-title">
          ${esc(p.nombre)}
          ${p.eliminado ? `<span class="prf-badge is-bloqueado" style="margin-left:6px;">Eliminado</span>` : ""}
        </div>
        <div class="adm-pub-sub">${esc(p.ocupacion)} · ${esc(p.zona)}, ${esc(p.ciudad)} · ★ ${esc(p.rating ?? "—")}</div>
        <div class="adm-pub-price">${formatCOP(p.presupuesto)}</div>
        <div class="adm-pub-owner">Edad: ${esc(p.edad ?? "—")}</div>
        <div class="adm-pub-actions">
          ${p.eliminado
            ? `<button type="button" class="adm-row-btn is-primary" data-restaurar-roomie="${esc(p.id)}">Restaurar</button>`
            : `<button type="button" class="adm-row-btn" data-ver-roomie="${esc(p.id)}">Ver perfil</button>
               <button type="button" class="adm-row-btn is-danger" data-eliminar-roomie="${esc(p.id)}" data-nombre="${esc(p.nombre)}">Eliminar</button>`}
        </div>
      </div>
    </div>`).join("");

  grid.querySelectorAll("[data-ver-roomie]").forEach((btn) => {
    btn.addEventListener("click", () => abrirModalRoomie(Number(btn.dataset.verRoomie)));
  });
  grid.querySelectorAll("[data-eliminar-roomie]").forEach((btn) => {
    btn.addEventListener("click", () => confirmarEliminarRoomie(Number(btn.dataset.eliminarRoomie), btn.dataset.nombre));
  });
  grid.querySelectorAll("[data-restaurar-roomie]").forEach((btn) => {
    btn.addEventListener("click", () => restaurarRoomie(Number(btn.dataset.restaurarRoomie)));
  });
}

async function restaurarRoomie(id) {
  const respuesta = await fetch(`${API_BASE}/admin/roomies/${id}/restaurar`, { method: "PATCH", headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  if (!respuesta.ok) {
    const datos = await respuesta.json().catch(() => ({}));
    mostrarToast(datos.mensaje || "No se pudo restaurar el perfil.");
    return;
  }
  mostrarToast("Perfil de roomie restaurado.");
  renderRoomies();
  renderResumen();
}

// Reutiliza el endpoint público GET /api/roomies/{id} (mismo criterio
// que abrirModalPublicacion con /api/publicaciones/{id}): trae
// características, propietario y reseñas ya formateadas, sin duplicar
// ese formateo en el controlador de admin. Antes esto era un enlace
// <a href="${appUrl('/roomie/{id}')}" target="_blank"> — pero una pestaña nueva
// comparte la misma sesión, así que el middleware zona.cliente la detectaba
// como "admin fuera de /admin" y la rebotaba de vuelta al panel. Un
// modal evita el problema de raíz: nunca se navega a otra ruta.
const ETIQUETAS_ESTADO_BUSQUEDA = {
  buscando: "Buscando roomie",
  ya_encontro: "Ya encontró roomie",
  pausado: "Búsqueda pausada",
};

async function abrirModalRoomie(id) {
  const respuesta = await fetch(`${API_BASE}/roomies/${id}`, { headers: cabecerasAutenticadas(false) });
  if (!respuesta.ok) return;
  const { persona: p } = await respuesta.json();
  const c = p.caracteristicas || {};

  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">${esc(p.nombre)}</p>
    <p class="adm-modal-sub">${esc(p.ocupacion)} · ${esc(p.zona)}, ${esc(p.ciudad)}</p>
    <img class="adm-modal-img" src="${esc(p.img || "")}" alt="${esc(p.nombre)}"/>
    <dl class="adm-modal-grid">
      <dt>Edad</dt><dd>${esc(p.edad ?? "—")}</dd>
      <dt>Género</dt><dd>${esc(p.genero || "—")}</dd>
      <dt>Presupuesto</dt><dd>${formatCOP(p.presupuesto)}</dd>
      <dt>Estado de búsqueda</dt><dd>${esc(ETIQUETAS_ESTADO_BUSQUEDA[p.estado_busqueda] || p.estado_busqueda || "—")}</dd>
      <dt>Rating</dt><dd>★ ${esc(p.rating ?? "—")} (${esc((p.resenas || []).length)} reseñas)</dd>
      <dt>Ambiente preferido</dt><dd>${esc(c.ambiente_preferido || "—")}</dd>
      <dt>Horario</dt><dd>${esc(c.horario || "—")}</dd>
      <dt>Busca mudarse</dt><dd>${esc(c.fecha_mudanza || "—")}</dd>
      <dt>Fumador</dt><dd>${esc(c.fumador ? "Sí" : "No")}</dd>
      <dt>Tiene mascota</dt><dd>${esc(c.tiene_mascota ? "Sí" : "No")}</dd>
    </dl>
    <p style="font-size:13.5px;color:#555;line-height:1.5;margin:0 0 18px;">${esc(p.descripcion || "")}</p>
    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCerrarDetalleRoomie">Cerrar</button>
      <button type="button" class="adm-row-btn is-danger" id="admEliminarRoomieDesdeModal">Eliminar perfil</button>
    </div>
  `);
  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCerrarDetalleRoomie").addEventListener("click", cerrarModal);
  document.getElementById("admEliminarRoomieDesdeModal").addEventListener("click", () => {
    cerrarModal();
    confirmarEliminarRoomie(p.id, p.nombre);
  });
}

function confirmarEliminarRoomie(id, nombre) {
  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">¿Eliminar el perfil de ${esc(nombre)}?</p>
    <p class="adm-modal-sub">Dejará de verse en la búsqueda de roomies. El registro no se borra de la base de datos: puedes restaurarlo después desde el filtro "Eliminados" si fue un error.</p>
    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCancelarEliminarRoomie">Cancelar</button>
      <button type="button" class="adm-row-btn is-danger" id="admConfirmarEliminarRoomie">Sí, eliminar</button>
    </div>
  `);
  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCancelarEliminarRoomie").addEventListener("click", cerrarModal);
  document.getElementById("admConfirmarEliminarRoomie").addEventListener("click", async () => {
    const respuesta = await fetch(`${API_BASE}/admin/roomies/${id}`, { method: "DELETE", headers: cabecerasAutenticadas(false) });
    if (manejarNoAutorizado(respuesta)) return;
    cerrarModal();
    mostrarToast("Perfil de roomie eliminado.");
    renderRoomies();
    renderResumen();
    renderReportes();
  });
}

function inicializarRoomies() {
  document.getElementById("admRoomiesSearch").addEventListener("input", debounce((e) => {
    busquedaRoomieActual = e.target.value.trim();
    renderRoomies();
  }, 300));

  document.querySelectorAll("#admRoomiesFiltros .prf-subtab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#admRoomiesFiltros .prf-subtab").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      filtroRoomieActual = btn.dataset.filtro;
      renderRoomies();
    });
  });

  renderRoomies();
}

// ============================================================
// REPORTES (HU-13)
// ============================================================
let filtroReporteActual = "pendiente";

// Reportes que esperan acción del admin: los pendientes y los que un
// moderador escaló.
function actualizarBadgeReportes(total) {
  const badge = document.getElementById("admReportesBadge");
  badge.hidden = total === 0;
  badge.textContent = total;
}

const ETIQUETAS_ESTADO_REPORTE = { pendiente: "Pendiente", escalado: "Escalado", resuelto: "Resuelto", descartado: "Descartado" };
const ETIQUETAS_TIPO_REPORTE = { publicacion: "Publicación", persona: "Roomie", usuario: "Usuario" };

async function renderReportes() {
  const cont = document.getElementById("admReportesList");
  const empty = document.getElementById("admReportesEmpty");

  const respuesta = await fetch(`${API_BASE}/admin/reportes?estado=${encodeURIComponent(filtroReporteActual)}`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await respuesta.json();
  const reportes = datos.reportes || [];
  actualizarBadgeReportes((datos.pendientes || 0) + (datos.escalados || 0));

  if (!reportes.length) {
    cont.innerHTML = "";
    empty.hidden = false;
    return;
  }
  empty.hidden = true;

  cont.innerHTML = reportes.map((r) => {
    const a = r.acciones || {};
    const nota = r.estado === "escalado"
      ? `<div class="adm-reporte-nota"><strong>Escalado${r.escalado_por ? ` por ${esc(r.escalado_por)}` : ""}${r.fecha_escalado ? ` · ${esc(formatFecha(r.fecha_escalado))}` : ""}:</strong> ${esc(r.nota_escalado || "Sin nota.")}</div>`
      : "";

    const lateral = (a.resolver || a.descartar || a.devolver)
      ? `<div class="adm-reporte-actions">
          ${a.resolver ? `<button type="button" class="adm-row-btn is-danger" data-resolver="${r.id}">Tomar acción</button>` : ""}
          ${a.devolver ? `<button type="button" class="adm-row-btn" data-devolver="${r.id}">Devolver a moderación</button>` : ""}
          ${a.descartar ? `<button type="button" class="adm-row-btn" data-descartar="${r.id}">Descartar</button>` : ""}
        </div>`
      : `<span class="adm-reporte-none">${r.gestionado_por ? `Gestionado por ${esc(r.gestionado_por)}` : "Sin acciones pendientes"}</span>`;

    return `
    <div class="adm-reporte-card">
      <div class="adm-reporte-icon">
        <svg viewBox="0 0 24 24"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L14.7 3.86a2 2 0 0 0-3.4 0z"/></svg>
      </div>
      <div class="adm-reporte-body">
        <div class="adm-reporte-top">
          <span class="adm-reporte-motivo">${esc(r.motivo)}</span>
          <span class="adm-reporte-tipo">${esc(ETIQUETAS_TIPO_REPORTE[r.tipo] || r.tipo)}</span>
          <span class="prf-badge is-${esc(r.estado)}">${esc(ETIQUETAS_ESTADO_REPORTE[r.estado] || r.estado)}</span>
        </div>
        <p class="adm-reporte-desc">${esc(r.descripcion)}</p>
        <div class="adm-reporte-meta">${esc(ETIQUETAS_TIPO_REPORTE[r.tipo] || r.tipo)}: ${esc(r.objetivo_titulo || "—")} · Reportado por ${esc(r.reportante)} · ${esc(formatFecha(r.fecha))}</div>
        ${nota}
      </div>
      <div class="adm-reporte-side">${lateral}</div>
    </div>`;
  }).join("");

  cont.querySelectorAll("[data-resolver]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const r = reportes.find((x) => x.id === Number(btn.dataset.resolver));
      if (r) abrirModalResolverReporte(r);
    });
  });
  cont.querySelectorAll("[data-devolver]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const r = reportes.find((x) => x.id === Number(btn.dataset.devolver));
      if (r) abrirModalDevolverReporte(r);
    });
  });
  cont.querySelectorAll("[data-descartar]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      const res = await peticionAccion(`/admin/reportes/${btn.dataset.descartar}/descartar`);
      if (!res) return;
      if (!res.ok) {
        mostrarToast(textoError(res, "No se pudo descartar el reporte."));
        btn.disabled = false;
        return;
      }
      mostrarToast("Reporte descartado.");
      renderReportes();
      renderResumen();
      renderAuditoria();
    });
  });
}

function abrirModalResolverReporte(r) {
  const ACCIONES = {
    publicacion: "Eliminar la publicación reportada",
    usuario: "Bloquear al usuario reportado",
    persona: "Eliminar el perfil reportado",
  };
  const accionLabel = ACCIONES[r.tipo] || "Marcar como resuelto";

  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">Resolver reporte</p>
    <p class="adm-modal-sub">${esc(r.motivo)} — ${esc(r.objetivo_titulo || "—")}</p>
    <p style="font-size:13.5px;color:#555;line-height:1.5;margin:0 0 18px;">${esc(r.descripcion)}</p>
    ${r.estado === "escalado" && r.nota_escalado ? `<div class="adm-reporte-nota" style="margin:0 0 14px;"><strong>Nota del moderador${r.escalado_por ? ` (${esc(r.escalado_por)})` : ""}:</strong> ${esc(r.nota_escalado)}</div>` : ""}
    <p class="adm-modal-sub" id="admResolverError" style="color:#c0261c;min-height:15px;"></p>
    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCancelarResolver">Cancelar</button>
      <button type="button" class="adm-row-btn is-danger" id="admAplicarAccion">${accionLabel}</button>
    </div>
  `);
  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCancelarResolver").addEventListener("click", cerrarModal);
  document.getElementById("admAplicarAccion").addEventListener("click", async (e) => {
    e.currentTarget.disabled = true;
    const res = await peticionAccion(`/admin/reportes/${r.id}/resolver`);
    if (!res) return;
    if (!res.ok) {
      document.getElementById("admResolverError").textContent = textoError(res, "No se pudo resolver el reporte.");
      e.currentTarget.disabled = false;
      return;
    }
    cerrarModal();
    mostrarToast("Reporte resuelto.");
    renderReportes();
    renderPublicaciones();
    renderRoomies();
    renderUsuarios();
    renderResumen();
    renderAuditoria();
  });
}

function abrirModalDevolverReporte(r) {
  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">Devolver a moderación</p>
    <p class="adm-modal-sub">${esc(r.motivo)} — ${esc(r.objetivo_titulo || "—")}. El reporte vuelve a "Pendientes" y el moderador que lo escaló recibe tu nota.</p>
    <textarea class="adm-modal-textarea" id="admNotaDevolver" maxlength="300" placeholder="Nota para el moderador (opcional)..."></textarea>
    <p class="adm-modal-sub" id="admDevolverError" style="color:#c0261c;min-height:15px;margin-top:-6px;"></p>
    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCancelarDevolver">Cancelar</button>
      <button type="button" class="adm-row-btn is-primary" id="admConfirmarDevolver">Devolver reporte</button>
    </div>
  `);
  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCancelarDevolver").addEventListener("click", cerrarModal);
  document.getElementById("admConfirmarDevolver").addEventListener("click", async (e) => {
    e.currentTarget.disabled = true;
    const nota = document.getElementById("admNotaDevolver").value.trim();
    const res = await peticionAccion(`/admin/reportes/${r.id}/devolver`, { cuerpo: nota ? { nota } : {} });
    if (!res) return;
    if (!res.ok) {
      document.getElementById("admDevolverError").textContent = textoError(res, "No se pudo devolver el reporte.");
      e.currentTarget.disabled = false;
      return;
    }
    cerrarModal();
    mostrarToast("Reporte devuelto a moderación.");
    renderReportes();
    renderResumen();
    renderAuditoria();
  });
}

function inicializarReportes() {
  document.querySelectorAll("#admReportesFiltros .prf-subtab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#admReportesFiltros .prf-subtab").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      filtroReporteActual = btn.dataset.filtro;
      renderReportes();
    });
  });
  renderReportes();
}

// ============================================================
// MENSAJES DE CONTACTO
// ------------------------------------------------------------
// Mismo patrón que la sección de Reportes: subtabs de estado +
// tarjetas reutilizando las clases .adm-reporte-* ya existentes
// (mismo layout: ícono, título, etiqueta, cuerpo, meta, acción).
// ============================================================
let filtroMensajeActual = "pendiente";

function actualizarBadgeMensajes(pendientes) {
  const badge = document.getElementById("admMensajesBadge");
  badge.hidden = pendientes === 0;
  badge.textContent = pendientes;
}

async function renderMensajes() {
  const cont = document.getElementById("admMensajesList");
  const empty = document.getElementById("admMensajesEmpty");

  const respuesta = await fetch(`${API_BASE}/admin/mensajes-contacto?estado=${encodeURIComponent(filtroMensajeActual)}`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await respuesta.json();
  const mensajes = datos.mensajes || [];
  actualizarBadgeMensajes(datos.pendientes || 0);

  if (!mensajes.length) {
    cont.innerHTML = "";
    empty.hidden = false;
    return;
  }
  empty.hidden = true;

  cont.innerHTML = mensajes.map((m) => `
    <div class="adm-reporte-card">
      <div class="adm-reporte-icon">
        <svg viewBox="0 0 24 24"><path d="M4 4h16v16H4z"/><path d="M4 6l8 7 8-7"/></svg>
      </div>
      <div class="adm-reporte-body">
        <div class="adm-reporte-top">
          <span class="adm-reporte-motivo">${esc(m.nombre)}</span>
          <span class="adm-reporte-tipo">${esc(m.asunto_label)}</span>
          <span class="prf-badge ${m.atendido ? "is-resuelto" : "is-pendiente"}">${m.atendido ? "Atendido" : "Pendiente"}</span>
        </div>
        <p class="adm-reporte-desc">${esc(m.mensaje)}</p>
        <div class="adm-reporte-meta">${esc(m.correo)} · ${esc(formatFecha(m.fecha))}${m.atendido && m.atendido_por ? ` · Atendido por ${esc(m.atendido_por)}` : ""}</div>
        ${m.respuesta ? `<div class="adm-reporte-nota"><strong>Respuesta enviada:</strong> ${esc(m.respuesta)}</div>` : ""}
      </div>
      <div class="adm-reporte-side">
        ${!m.atendido ? `
          <div class="adm-reporte-actions">
            <button type="button" class="adm-row-btn is-primary" data-responder="${m.id}">Responder por correo</button>
            <button type="button" class="adm-row-btn" data-atender="${m.id}">Marcar atendido</button>
          </div>` : `<span class="adm-reporte-none">Sin acciones pendientes</span>`}
      </div>
    </div>`).join("");

  cont.querySelectorAll("[data-responder]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const m = mensajes.find((x) => x.id === Number(btn.dataset.responder));
      if (m) abrirModalResponderMensaje(m);
    });
  });
  cont.querySelectorAll("[data-atender]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const res = await peticionAccion(`/admin/mensajes-contacto/${btn.dataset.atender}/atender`);
      if (!res) return;
      mostrarToast(res.ok ? "Mensaje marcado como atendido." : textoError(res, "No se pudo marcar el mensaje."));
      renderMensajes();
      renderAuditoria();
    });
  });
}

function abrirModalResponderMensaje(m) {
  abrirModal(`
    <button class="adm-modal-close" type="button" id="admModalCloseBtn">&times;</button>
    <p class="adm-modal-title">Responder a ${esc(m.nombre)}</p>
    <p class="adm-modal-sub">${esc(m.asunto_label)} · ${esc(m.correo)}</p>
    <div class="adm-reporte-nota" style="margin:0 0 14px;"><strong>Su mensaje:</strong> ${esc(m.mensaje)}</div>
    <textarea class="adm-modal-textarea" id="admTextoRespuesta" maxlength="5000" style="min-height:140px;" placeholder="Escribe la respuesta (mínimo 10 caracteres). Se enviará por correo a ${esc(m.correo)}."></textarea>
    <p class="adm-modal-sub" id="admResponderError" style="color:#c0261c;min-height:15px;margin-top:-6px;"></p>
    <div class="adm-modal-buttons">
      <button type="button" class="adm-row-btn" id="admCancelarResponder">Cancelar</button>
      <button type="button" class="adm-row-btn is-primary" id="admEnviarRespuesta">Enviar respuesta</button>
    </div>
  `);
  document.getElementById("admModalCloseBtn").addEventListener("click", cerrarModal);
  document.getElementById("admCancelarResponder").addEventListener("click", cerrarModal);
  document.getElementById("admEnviarRespuesta").addEventListener("click", async (e) => {
    const texto = document.getElementById("admTextoRespuesta").value.trim();
    const errorEl = document.getElementById("admResponderError");
    if (texto.length < 10) {
      errorEl.textContent = "La respuesta debe tener al menos 10 caracteres.";
      return;
    }
    const btn = e.currentTarget;
    btn.disabled = true;
    btn.textContent = "Enviando...";
    const res = await peticionAccion(`/admin/mensajes-contacto/${m.id}/responder`, { metodo: "POST", cuerpo: { respuesta: texto } });
    if (!res) return;
    if (!res.ok) {
      errorEl.textContent = textoError(res, "No se pudo enviar la respuesta.");
      btn.disabled = false;
      btn.textContent = "Enviar respuesta";
      if (res.status === 409) renderMensajes();
      return;
    }
    cerrarModal();
    mostrarToast("Respuesta enviada por correo.");
    renderMensajes();
    renderAuditoria();
  });
}

function inicializarMensajes() {
  document.querySelectorAll("#admMensajesFiltros .prf-subtab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#admMensajesFiltros .prf-subtab").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      filtroMensajeActual = btn.dataset.filtro;
      renderMensajes();
    });
  });
  renderMensajes();
}

// ============================================================
// AUDITORÍA (solo lectura)
// ------------------------------------------------------------
// Registro de lo que hacen moderadores y administradores (tabla
// accion_moderacion). Lo alimenta el servidor en cada acción; aquí solo se
// consulta, con filtros y paginación (GET /api/admin/auditoria).
// ============================================================
let paginaAuditoria = 1;
let etiquetasAuditoriaCargadas = false;

function resumirDetalleAuditoria(detalle) {
  if (!detalle || typeof detalle !== "object") return "—";
  const partes = Object.entries(detalle)
    .filter(([, v]) => v !== null && v !== "" && typeof v !== "object")
    .map(([k, v]) => `<span class="adm-audit-kv"><b>${esc(k.replace(/_/g, " "))}:</b> ${esc(v)}</span>`);
  return partes.length ? partes.join(" ") : "—";
}

async function renderAuditoria() {
  const body = document.getElementById("admAuditoriaBody");
  if (!body) return;
  const empty = document.getElementById("admAuditoriaEmpty");

  const params = new URLSearchParams({ page: String(paginaAuditoria) });
  const accion = valorSelect(document.getElementById("admAuditoriaAccion"));
  const rol = valorSelect(document.getElementById("admAuditoriaRol"));
  const q = document.getElementById("admAuditoriaSearch").value.trim();
  const desde = document.getElementById("admAuditoriaDesde").value;
  const hasta = document.getElementById("admAuditoriaHasta").value;
  if (accion) params.set("accion", accion);
  if (rol) params.set("rol", rol);
  if (q) params.set("q", q);
  if (desde) params.set("desde", desde);
  if (hasta) params.set("hasta", hasta);

  const res = await peticionAccion(`/admin/auditoria?${params}`, { metodo: "GET" });
  if (!res) return;
  if (!res.ok) {
    body.innerHTML = "";
    empty.hidden = false;
    empty.textContent = textoError(res, "No se pudo cargar la auditoría.");
    return;
  }

  const datos = res.datos;

  if (!etiquetasAuditoriaCargadas) {
    // Las acciones llegan con la primera respuesta: se reconstruye el select
    // con ellas (el escucha de cambios vive en el contenedor, no se pierde).
    pintarSelectAccionAuditoria(datos.etiquetas || {});
    etiquetasAuditoriaCargadas = true;
  }

  const filas = datos.acciones || [];
  document.getElementById("admAuditoriaPagina").textContent = `Página ${datos.pagina} de ${datos.ultima_pagina} · ${datos.total} registros`;
  document.getElementById("admAuditoriaPrev").disabled = datos.pagina <= 1;
  document.getElementById("admAuditoriaNext").disabled = datos.pagina >= datos.ultima_pagina;

  if (!filas.length) {
    body.innerHTML = "";
    empty.hidden = false;
    empty.textContent = "No hay acciones registradas con esos filtros.";
    return;
  }
  empty.hidden = true;

  body.innerHTML = filas.map((f) => `
    <tr>
      <td data-label="Fecha">${esc(new Date(f.fecha).toLocaleString("es-CO", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }))}</td>
      <td data-label="Quién">${esc(f.actor)} <span class="adm-tipo-badge ${f.rol === "admin" ? "is-admin" : "is-moderador"}">${f.rol === "admin" ? "Admin" : "Moderador"}</span></td>
      <td data-label="Acción">${esc(f.accion_label)}</td>
      <td data-label="Sobre">${esc(f.entidad_titulo || "—")}</td>
      <td data-label="Detalle">${resumirDetalleAuditoria(f.detalle)}</td>
    </tr>`).join("");
}

function pintarSelectAccionAuditoria(etiquetas) {
  const host = document.getElementById("admAuditoriaAccionHost");
  host.innerHTML = selectHtml({
    id: "admAuditoriaAccion",
    opciones: [["", "Todas las acciones"], ...Object.entries(etiquetas)],
    valor: "",
  });
  enlazarSelects(host);
}

function inicializarAuditoria() {
  if (!document.getElementById("admAuditoriaBody")) return;

  const recargar = () => { paginaAuditoria = 1; renderAuditoria(); };

  pintarSelectAccionAuditoria({});
  const rolHost = document.getElementById("admAuditoriaRolHost");
  rolHost.innerHTML = selectHtml({
    id: "admAuditoriaRol",
    opciones: [["", "Cualquier rol"], ["moderador", "Moderador"], ["admin", "Administrador"]],
    valor: "",
  });
  enlazarSelects(rolHost);

  // "select-cambio" burbujea desde el select hasta su contenedor.
  ["admAuditoriaAccionHost", "admAuditoriaRolHost"].forEach((id) => {
    document.getElementById(id).addEventListener("select-cambio", recargar);
  });
  ["admAuditoriaDesde", "admAuditoriaHasta"].forEach((id) => {
    document.getElementById(id).addEventListener("change", recargar);
  });
  document.getElementById("admAuditoriaSearch").addEventListener("input", debounce(recargar, 300));
  document.getElementById("admAuditoriaPrev").addEventListener("click", () => { paginaAuditoria = Math.max(1, paginaAuditoria - 1); renderAuditoria(); });
  document.getElementById("admAuditoriaNext").addEventListener("click", () => { paginaAuditoria += 1; renderAuditoria(); });

  renderAuditoria();
}

// ============================================================
// GRÁFICA: REPORTES POR DÍA (últimos 14 días)
// ------------------------------------------------------------
// El backend (GET /api/admin/reportes/grafica) ya entrega el conteo
// agrupado por día y tipo; aquí solo se dibuja el SVG, igual que
// antes, sin depender de ninguna librería externa.
// ============================================================
async function renderGraficaReportes() {
  const cont = document.getElementById("admGraficaReportes");

  const respuesta = await fetch(`${API_BASE}/admin/reportes/grafica`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const { dias } = await respuesta.json();

  const claves = Object.keys(dias);
  const totalReportes = claves.reduce((acc, k) => acc + dias[k].publicacion + dias[k].otros, 0);

  if (!totalReportes) {
    cont.innerHTML = `<p class="adm-chart-empty">Aún no hay reportes registrados en este rango de fechas.</p>`;
    return;
  }

  const maxValor = Math.max(1, ...claves.map((k) => Math.max(dias[k].publicacion, dias[k].otros)));

  const anchoGrupo = 34;
  const espacio = 12;
  const altoChart = 170;
  const altoBarras = altoChart - 30;
  const anchoChart = claves.length * (anchoGrupo + espacio) + espacio;

  const barras = claves.map((key, i) => {
    const c = dias[key];
    const x = espacio + i * (anchoGrupo + espacio);
    const barW = (anchoGrupo - 4) / 2;

    const hPub = Math.round((c.publicacion / maxValor) * altoBarras);
    const hOtros = Math.round((c.otros / maxValor) * altoBarras);
    const yPub = altoChart - hPub - 20;
    const yOtros = altoChart - hOtros - 20;

    const label = new Date(key + "T00:00:00").toLocaleDateString("es-CO", { day: "2-digit", month: "short" }).replace(".", "");

    return `
      <g>
        ${c.publicacion ? `<rect x="${x}" y="${yPub}" width="${barW}" height="${Math.max(hPub, 2)}" rx="3" fill="#1a9ecf"><title>${c.publicacion} publicación(es) reportada(s) el ${label}</title></rect>` : ""}
        ${c.otros ? `<rect x="${x + barW + 4}" y="${yOtros}" width="${barW}" height="${Math.max(hOtros, 2)}" rx="3" fill="#e08a1e"><title>${c.otros} usuario(s)/roomie(s) reportado(s) el ${label}</title></rect>` : ""}
        <text x="${x + anchoGrupo / 2}" y="${altoChart - 4}" font-size="9" fill="#999" text-anchor="middle">${label}</text>
      </g>`;
  }).join("");

  cont.innerHTML = `
    <div class="adm-chart-legend">
      <span><i style="background:#1a9ecf"></i> Publicaciones</span>
      <span><i style="background:#e08a1e"></i> Usuarios y roomies</span>
    </div>
    <svg viewBox="0 0 ${anchoChart} ${altoChart}" class="adm-chart-svg" preserveAspectRatio="xMinYMin meet">
      ${barras}
    </svg>`;
}

// ============================================================
// RESUMEN
// ------------------------------------------------------------
// 'buscadores'/'oferentes' ya no existen: el backend ahora entrega
// 'clientes' y 'administradores' (ver AdminController::resumen()).
// ============================================================
async function renderResumen() {
  const respuesta = await fetch(`${API_BASE}/admin/resumen`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const s = await respuesta.json();

  const stats = [
    { label: "Usuarios registrados", value: s.usuarios_registrados },
    { label: "Clientes", value: s.clientes },
    { label: "Administradores", value: s.administradores },
    { label: "Moderadores", value: s.moderadores },
    { label: "Usuarios bloqueados", value: s.usuarios_bloqueados, alert: s.usuarios_bloqueados > 0 },
    { label: "Publicaciones activas", value: s.publicaciones_activas },
    { label: "Roomies publicados", value: s.roomies_publicados },
    { label: "Reportes pendientes", value: s.reportes_pendientes, alert: s.reportes_pendientes > 0 },
    { label: "Reportes escalados por moderación", value: s.reportes_escalados, alert: s.reportes_escalados > 0 },
    { label: "Mensajes de contacto pendientes", value: s.mensajes_contacto_pendientes, alert: s.mensajes_contacto_pendientes > 0 },
  ];

  document.getElementById("admStatsGrid").innerHTML = stats.map((s) => `
    <div class="adm-stat-card ${s.alert ? "is-alert" : ""}">
      <div class="adm-stat-value">${s.value}</div>
      <div class="adm-stat-label">${s.label}</div>
    </div>`).join("");

  renderGraficaReportes();
}

// ============================================================
// INICIALIZACIÓN DEL PANEL
// ============================================================
renderResumen();
inicializarUsuarios();
inicializarPublicaciones();
inicializarRoomies();
inicializarReportes();
inicializarMensajes();
inicializarAuditoria();
activarPanelPorHash();
