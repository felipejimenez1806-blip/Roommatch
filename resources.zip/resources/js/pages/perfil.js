// ============================================================
// ROOMMATCH – lógica de la página PERFIL (ajustes de cuenta)
// ------------------------------------------------------------
// Misma UX que la versión original, pero contra la API real:
//   - Datos personales -> PUT /api/usuario
//   - Foto de perfil -> POST /api/usuario/foto
//   - Convivencia -> PUT /api/usuario/convivencia
//   - Favoritos (habitaciones) -> GET /api/mis-favoritos/habitaciones
//   - Reservas -> GET /api/mis-reservas + calificar/reportar
//   - Mis citas -> GET /api/mis-citas + calificar/reportar
//   - Notificaciones -> GET /api/notificaciones + marcar-leidas
// El navbar (avatar/nombre/badge) ya lo maneja nav.js, compartido en
// todas las páginas — este archivo ya NO lo toca directamente.
// Favoritos->Roomies queda con estado vacío: pendiente de migrar.
//
// La sesión (token/usuario) se maneja en core/auth.js.
//
// CAMBIO (roles): con el ENUM tipo_usuario reducido a cliente/admin,
// el campo "Tipo de cuenta" se quitó de Datos personales (ya no se
// muestra ni se edita), y el panel "Información convivencial" ya NO
// se ramifica por tipoUsuario buscador/oferente — ahora muestra
// AMBOS bloques (estilo de vida + reglas del hogar) en pestañas,
// disponibles para todo cliente sin importar su rol.
// ============================================================

import { API_BASE, appUrl, LIMITES as L } from "../core/config.js";
import { requerirSesion, obtenerUsuario, actualizarUsuario, cabecerasAutenticadas, manejarNoAutorizado } from "../core/auth.js";
import { esc } from "../core/html.js";
import { OPCIONES_AMBIENTE } from "../core/convivencia.js";
import {
  validarHabitantes, validarPresupuesto, validarTextoOpcional, normalizarTelefono, telefonoNacional, formatearTelefono, MENSAJE_TELEFONO,
  bloquearTeclasNoEnteras, leerRespuesta, erroresPorCampo, mensajeGeneral,
} from "../core/validacion.js";

requerirSesion();
let usuarioActual = obtenerUsuario();

function guardarUsuarioLocal(usuario) {
  usuarioActual = usuario;
  actualizarUsuario(usuario);
}

document.getElementById("logoutBtnSidebar").addEventListener("click", () => {
  window.RoommatchNav.cerrarSesion();
});

// ---------- FOTO DE PERFIL ----------
const FOTO_MAX_LADO = 240;
const FOTO_CALIDAD = 0.85;
const FOTO_MAX_PESO_ORIGINAL = 5 * 1024 * 1024;

function pintarIdentidad() {
  const avatarBig = document.getElementById("prfAvatarBig");
  const quitarBtn = document.getElementById("quitarFotoBtn");
  const inicial = (usuarioActual.nombre || "U").trim().charAt(0).toUpperCase();

  if (usuarioActual.fotoPerfil) {
    avatarBig.innerHTML = `<img src="${esc(usuarioActual.fotoPerfil)}" alt="${esc(usuarioActual.nombre)}"/>`;
    quitarBtn.hidden = false;
  } else {
    avatarBig.textContent = inicial;
    quitarBtn.hidden = true;
  }
}
pintarIdentidad();

function mostrarErrorFoto(mensaje) {
  const el = document.getElementById("fotoError");
  el.textContent = mensaje;
  el.classList.toggle("is-visible", Boolean(mensaje));
}

function comprimirImagen(archivo) {
  return new Promise((resolve, reject) => {
    const lector = new FileReader();
    lector.onerror = () => reject(new Error("No se pudo leer el archivo."));
    lector.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("El archivo no es una imagen válida."));
      img.onload = () => {
        const lado = Math.min(FOTO_MAX_LADO, Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = lado;
        canvas.height = lado;
        const ctx = canvas.getContext("2d");
        const escala = Math.max(lado / img.width, lado / img.height);
        const anchoEscalado = img.width * escala;
        const altoEscalado = img.height * escala;
        const dx = (lado - anchoEscalado) / 2;
        const dy = (lado - altoEscalado) / 2;
        ctx.drawImage(img, dx, dy, anchoEscalado, altoEscalado);
        resolve(canvas.toDataURL("image/jpeg", FOTO_CALIDAD));
      };
      img.src = lector.result;
    };
    lector.readAsDataURL(archivo);
  });
}

document.getElementById("fotoInput").addEventListener("change", async (e) => {
  const archivo = e.target.files[0];
  e.target.value = "";
  if (!archivo) return;

  mostrarErrorFoto("");
  if (!archivo.type.startsWith("image/")) {
    mostrarErrorFoto("Selecciona un archivo de imagen (JPG, PNG o WEBP).");
    return;
  }
  if (archivo.size > FOTO_MAX_PESO_ORIGINAL) {
    mostrarErrorFoto("La imagen pesa demasiado. Usa una de menos de 5MB.");
    return;
  }

  try {
    const dataUrl = await comprimirImagen(archivo);
    const respuesta = await fetch(`${API_BASE}/usuario/foto`, {
      method: "POST",
      headers: cabecerasAutenticadas(),
      body: JSON.stringify({ foto: dataUrl }),
    });
    if (manejarNoAutorizado(respuesta)) return;
    const datos = await leerRespuesta(respuesta);
    if (!respuesta.ok) {
      mostrarErrorFoto(erroresPorCampo(datos).foto || mensajeGeneral(respuesta, datos, "No se pudo subir la foto."));
      return;
    }
    guardarUsuarioLocal(datos.usuario);
    pintarIdentidad();
    window.RoommatchNav.renderNavbar();
  } catch (err) {
    mostrarErrorFoto("No se pudo procesar la imagen. Intenta con otra.");
  }
});

document.getElementById("quitarFotoBtn").addEventListener("click", async () => {
  const respuesta = await fetch(`${API_BASE}/usuario/foto`, {
    method: "POST",
    headers: cabecerasAutenticadas(),
    body: JSON.stringify({ foto: null }),
  });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await leerRespuesta(respuesta);
  if (!respuesta.ok) {
    mostrarErrorFoto(mensajeGeneral(respuesta, datos, "No se pudo quitar la foto."));
    return;
  }
  guardarUsuarioLocal(datos.usuario);
  pintarIdentidad();
  window.RoommatchNav.renderNavbar();
});

// ============================================================
// NAVEGACIÓN ENTRE PANELES (sidebar)
// ============================================================
document.querySelectorAll(".prf-nav-item[data-panel]").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".prf-nav-item[data-panel]").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".prf-panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.panel).classList.add("active");

    if (btn.dataset.panel === "panelNotificaciones") {
      marcarNotificacionesLeidas();
    }
  });
});

function activarPanelPorHash() {
  const panelId = window.location.hash.replace("#", "");
  if (!panelId) return;
  const btn = document.querySelector(`.prf-nav-item[data-panel="${panelId}"]`);
  if (btn) btn.click();
}
window.addEventListener("hashchange", activarPanelPorHash);

// ============================================================
// HELPERS COMPARTIDOS
// ============================================================
function formatCOP(n) {
  return "$" + Math.round(n).toLocaleString("es-CO") + " COP";
}
function formatFechaCorta(fechaISO) {
  if (!fechaISO) return "Sin definir";
  return new Date(fechaISO + "T00:00:00").toLocaleDateString("es-CO", { day: "2-digit", month: "short", year: "numeric" });
}
function formatFechaHora(fechaISO) {
  const d = new Date(fechaISO);
  const fecha = d.toLocaleDateString("es-CO", { day: "2-digit", month: "short", year: "numeric" });
  const hora = d.toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" });
  return `${fecha} · ${hora}`;
}
function formatHora12(horaISO) {
  if (!horaISO) return null;
  const [h, m] = horaISO.split(":").map(Number);
  const periodo = h >= 12 ? "p. m." : "a. m.";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${String(m).padStart(2, "0")} ${periodo}`;
}
const ETIQUETAS_DURACION = { "1-3": "1 a 3 meses", "3-6": "3 a 6 meses", "6-12": "6 a 12 meses", "12+": "Más de 12 meses" };
// El backend usa 'aceptada' (no 'aprobada') tanto para reservas como para citas.
const ETIQUETAS_BADGE = { pendiente: "Pendiente", aceptada: "Aceptada", rechazada: "Rechazada", cancelada: "Cancelada" };
const ETIQUETAS_TIPO_ENCUENTRO = { sitio: "En el lugar", publico: "Sitio público", otro: "Otro" };

const MOTIVOS_REPORTE_PUBLICACION = [
  "El lugar no correspondía a lo publicado",
  "El oferente no se presentó a la visita",
  "Comportamiento inapropiado durante la visita",
  "Cobro de valores no acordados",
  "Otro",
];
const MOTIVOS_REPORTE_ROOMIE = [
  "No se presentó a la cita",
  "Comportamiento inapropiado durante el encuentro",
  "El perfil no correspondía a la persona real",
  "Mensajes ofensivos o acoso",
  "Otro",
];

// ============================================================
// 1) DATOS PERSONALES
// ============================================================
const CAMPOS_PERSONALES = [
  { key: "nombre", label: "Nombre completo", type: "text", placeholder: "Tu nombre completo" },
  { key: "email", label: "Email", type: "email", placeholder: "correo@ejemplo.com" },
  { key: "telefono", label: "Teléfono", type: "tel", placeholder: "Ej. 300 123 4567" },
  { key: "direccion", label: "Dirección / Localidad", type: "text", placeholder: "Ej. Kennedy, Bogotá" },
  {
    key: "genero", label: "Género", type: "select", placeholder: "",
    options: [
      { value: "masculino", label: "Masculino" },
      { value: "femenino", label: "Femenino" },
      { value: "otro", label: "Otro" },
      { value: "prefiero_no_decir", label: "Prefiero no decir" },
    ],
  },
];

function etiquetaOpcion(campo, valor) {
  const opcion = campo.options?.find((o) => o.value === valor);
  return opcion ? opcion.label : valor;
}

function renderDatosPersonales() {
  const cont = document.getElementById("datosPersonalesList");
  cont.innerHTML = CAMPOS_PERSONALES.map((campo) => {
    const valor = usuarioActual[campo.key];
    const textoMostrado = valor ? (campo.type === "select" ? etiquetaOpcion(campo, valor) : campo.key === "telefono" ? formatearTelefono(valor) : valor) : "Sin definir";
    return `
      <div class="prf-field-row" data-field="${esc(campo.key)}">
        <span class="prf-field-label">${esc(campo.label)}</span>
        <span class="prf-field-value${esc(valor ? "" : " is-empty")}" data-display>${esc(textoMostrado)}</span>
        <button type="button" class="prf-edit-btn" data-action="edit">Edit</button>
      </div>`;
  }).join("");

  cont.querySelectorAll('.prf-field-row [data-action="edit"]').forEach((btn) => {
    btn.addEventListener("click", () => activarEdicionCampo(btn.closest(".prf-field-row")));
  });
}

function activarEdicionCampo(row) {
  const key = row.dataset.field;
  const campo = CAMPOS_PERSONALES.find((c) => c.key === key);
  const display = row.querySelector("[data-display]");
  const btn = row.querySelector('[data-action="edit"]');
  const valorActual = key === "telefono" ? telefonoNacional(usuarioActual[key] || "") : (usuarioActual[key] || "");

  let inputHtml;
  if (campo.type === "select") {
    inputHtml = `<select class="prf-field-select" data-input>
      <option value="">Selecciona una opción</option>
      ${campo.options.map((o) => `<option value="${esc(o.value)}"${esc(o.value === valorActual ? " selected" : "")}>${esc(o.label)}</option>`).join("")}
    </select>`;
  } else {
    inputHtml = `<input class="prf-field-input" data-input type="${esc(campo.type)}" placeholder="${esc(campo.placeholder)}" value="${esc(valorActual.toString())}"/>`;
  }

  display.outerHTML = `${inputHtml}<div class="prf-field-error" data-error></div>`;
  btn.textContent = "Guardar";
  btn.classList.add("is-save");
  btn.dataset.action = "save";

  row.querySelector("[data-input]").focus();
  btn.replaceWith(btn.cloneNode(true));
  row.querySelector('[data-action="save"]').addEventListener("click", () => guardarCampo(row));
}

async function guardarCampo(row) {
  const key = row.dataset.field;
  const input = row.querySelector("[data-input]");
  const errorEl = row.querySelector("[data-error]");
  const valor = input.value.trim();

  let invalido = false, mensajeError = "";
  if (key === "nombre" && (valor.length < 3 || valor.length > 150)) { invalido = true; mensajeError = "Ingresa tu nombre completo (entre 3 y 150 caracteres)."; }
  if (key === "email" && (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valor) || valor.length > 150)) { invalido = true; mensajeError = "Ingresa un correo válido (máximo 150 caracteres)."; }
  if (key === "telefono" && !normalizarTelefono(valor)) { invalido = true; mensajeError = MENSAJE_TELEFONO; }
  if (key === "direccion" && (valor.length < 3 || valor.length > 255)) { invalido = true; mensajeError = "Ingresa una dirección válida (entre 3 y 255 caracteres)."; }
  if (key === "genero" && !valor) { invalido = true; mensajeError = "Selecciona una opción."; }

  if (invalido) {
    errorEl.textContent = mensajeError;
    errorEl.classList.add("is-visible");
    return;
  }

  const payload = {
    nombre: key === "nombre" ? valor : usuarioActual.nombre,
    email: key === "email" ? valor : usuarioActual.email,
    telefono: key === "telefono" ? valor : (usuarioActual.telefono || ""),
    direccion: key === "direccion" ? valor : usuarioActual.direccion,
    genero: key === "genero" ? valor : usuarioActual.genero,
  };

  const respuesta = await fetch(`${API_BASE}/usuario`, {
    method: "PUT",
    headers: cabecerasAutenticadas(),
    body: JSON.stringify(payload),
  });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await leerRespuesta(respuesta);

  if (!respuesta.ok) {
    // 422: Laravel manda `errors` por campo (nunca `mensaje`). Se muestra el
    // del campo que se está editando, o el primero que haya.
    const porCampo = erroresPorCampo(datos);
    errorEl.textContent = respuesta.status === 422
      ? (porCampo[key] || Object.values(porCampo)[0] || "No se pudo guardar. Verifica el dato.")
      : mensajeGeneral(respuesta, datos, "No se pudo guardar. Verifica el dato.");
    errorEl.classList.add("is-visible");
    return;
  }

  guardarUsuarioLocal(datos.usuario);
  if (key === "nombre" || key === "email") window.RoommatchNav.renderNavbar();

  renderDatosPersonales();
}

// ============================================================
// 2) INFORMACIÓN CONVIVENCIAL
// ------------------------------------------------------------
// Ya no depende de tipoUsuario (buscador/oferente): todo cliente ve
// ambos bloques —"Mi estilo de vida" y "Reglas de mi hogar"— en
// pestañas, porque cualquier cliente puede tanto buscar como ofrecer
// espacio. Los datos se siguen guardando en el mismo JSON
// preferenciasConvivencia; los dos bloques comparten esa misma bolsa
// de claves, así que llenar uno no borra el otro.
// ============================================================

function mostrarNotaGuardado() {
  const nota = document.getElementById("convivenciaSaveNote");
  nota.classList.add("show");
  clearTimeout(mostrarNotaGuardado._t);
  mostrarNotaGuardado._t = setTimeout(() => nota.classList.remove("show"), 1400);
}

// Mismos topes que el servidor (config/roommatch.php). Un campo vacío (null)
// siempre es válido: significa "borrar el dato".
const VALIDADORES_CONV = {
  numero_habitantes: validarHabitantes,
  presupuesto_max: validarPresupuesto,
  horario_entrada: (v) => validarTextoOpcional(v, { sujeto: "El horario de entrada", max: L.texto_corto_max }),
  horario_silencio: (v) => validarTextoOpcional(v, { sujeto: "El horario de silencio", max: L.texto_corto_max }),
};

function mostrarErrorConvivencia(mensaje) {
  let el = document.getElementById("convivenciaError");
  if (!el) {
    el = document.createElement("p");
    el.id = "convivenciaError";
    el.className = "prf-field-error";
    document.getElementById("convivenciaSaveNote").insertAdjacentElement("afterend", el);
  }
  el.textContent = mensaje;
  el.classList.toggle("is-visible", Boolean(mensaje));
}

// Devuelve el control al valor que tenía antes del intento fallido.
function restaurarControl(el, previo) {
  if (!el) return;
  if (el.type === "checkbox") el.checked = Boolean(previo);
  else el.value = previo ?? "";
}

async function actualizarPreferencia(campo, valor, el) {
  mostrarErrorConvivencia("");
  const previo = usuarioActual.preferenciasConvivencia?.[campo] ?? null;

  const validar = VALIDADORES_CONV[campo];
  const mensaje = validar && valor !== null ? validar(valor) : null;
  if (mensaje) {
    mostrarErrorConvivencia(mensaje);
    restaurarControl(el, previo);
    return;
  }

  let respuesta, datos;
  try {
    respuesta = await fetch(`${API_BASE}/usuario/convivencia`, {
      method: "PUT",
      headers: cabecerasAutenticadas(),
      body: JSON.stringify({ [campo]: valor }),
    });
    if (manejarNoAutorizado(respuesta)) return;
    datos = await leerRespuesta(respuesta);
  } catch (err) {
    mostrarErrorConvivencia("No se pudo conectar con el servidor. Intenta de nuevo.");
    restaurarControl(el, previo);
    return;
  }

  if (!respuesta.ok) {
    const porCampo = erroresPorCampo(datos);
    mostrarErrorConvivencia(porCampo[campo] || Object.values(porCampo)[0] || mensajeGeneral(respuesta, datos, "No se pudo guardar el cambio."));
    restaurarControl(el, previo);
    return;
  }

  // Solo ahora (el servidor ya lo aceptó) se actualiza el estado local.
  usuarioActual.preferenciasConvivencia = usuarioActual.preferenciasConvivencia || {};
  usuarioActual.preferenciasConvivencia[campo] = valor;
  actualizarUsuario(usuarioActual);
  mostrarNotaGuardado();
}

function toggleRow(campo, label, valorActual) {
  return `
    <div class="prf-toggle-row">
      <span class="prf-toggle-label">${esc(label)}</span>
      <label class="prf-switch">
        <input type="checkbox" data-conv-toggle="${esc(campo)}" ${esc(valorActual ? "checked" : "")}/>
        <span class="prf-switch-track"></span>
      </label>
    </div>`;
}
function selectField(campo, label, opciones, valorActual) {
  return `
    <div class="prf-conv-field">
      <label>${esc(label)}</label>
      <select data-conv-select="${esc(campo)}">
        <option value="">Selecciona una opción</option>
        ${Object.entries(opciones).map(([v, txt]) => `<option value="${esc(v)}"${esc(v === valorActual ? " selected" : "")}>${esc(txt)}</option>`).join("")}
      </select>
    </div>`;
}
function numberField(campo, label, valorActual, placeholder) {
  return `
    <div class="prf-conv-field">
      <label>${esc(label)}</label>
      <input type="number" min="0" data-conv-number="${esc(campo)}" value="${esc(valorActual ?? "")}" placeholder="${esc(placeholder)}"/>
    </div>`;
}
function textField(campo, label, valorActual, placeholder) {
  return `
    <div class="prf-conv-field">
      <label>${esc(label)}</label>
      <input type="text" data-conv-text="${esc(campo)}" value="${esc(valorActual ?? "")}" placeholder="${esc(placeholder)}"/>
    </div>`;
}

function bloqueEstiloVida(p) {
  return `
    <div class="prf-conv-group">
      <p class="prf-conv-group-title">Estilo de vida</p>
      <div class="prf-toggle-grid">
        ${toggleRow("fumador", "Fumador/a", p.fumador)}
        ${toggleRow("tiene_mascota", "Tiene mascota propia", p.tiene_mascota)}
        ${toggleRow("ordenado", "Ordenado/a", p.ordenado)}
        ${toggleRow("sociable", "Sociable", p.sociable)}
        ${toggleRow("madrugador", "Madrugador/a", p.madrugador)}
        ${toggleRow("trasnochador", "Trasnochador/a", p.trasnochador)}
      </div>
    </div>
    <div class="prf-conv-group">
      <p class="prf-conv-group-title">Qué buscas</p>
      <div class="prf-toggle-grid">
        ${toggleRow("quiere_amueblado", "Busca lugar amueblado", p.quiere_amueblado)}
        ${toggleRow("quiere_bano_privado", "Busca baño privado", p.quiere_bano_privado)}
        ${toggleRow("cerca_transporte_publico", "Cerca a transporte público", p.cerca_transporte_publico)}
        ${toggleRow("cerca_universidad", "Cerca a universidad", p.cerca_universidad)}
      </div>
      ${selectField("ambiente_preferido", "Ambiente que prefieres", OPCIONES_AMBIENTE, p.ambiente_preferido)}
      ${selectField("horario", "Tu horario habitual", { diurno: "Diurno", nocturno: "Nocturno", mixto: "Mixto" }, p.horario)}
      ${selectField("tiempo_busqueda", "Tiempo de búsqueda", { corto: "Corto plazo", largo: "Largo plazo" }, p.tiempo_busqueda)}
      ${selectField("fecha_mudanza", "Fecha de mudanza", { inmediata: "Inmediata", "1mes": "En un mes", flexible: "Flexible" }, p.fecha_mudanza)}
      ${numberField("presupuesto_max", "Presupuesto máximo mensual", p.presupuesto_max, "Ej. 500000")}
    </div>`;
}

function bloqueReglasHogar(p) {
  return `
    <div class="prf-conv-group">
      <p class="prf-conv-group-title">Ambiente del hogar</p>
      ${selectField("ambiente_hogar", "Ambiente de la casa", OPCIONES_AMBIENTE, p.ambiente_hogar)}
      ${numberField("numero_habitantes", "Número de habitantes actuales", p.numero_habitantes, "Ej. 2")}
      ${textField("horario_entrada", "Horario de entrada permitido", p.horario_entrada, "Ej. Hasta las 11:00pm")}
      ${textField("horario_silencio", "Horario de silencio", p.horario_silencio, "Ej. 10:00pm - 7:00am")}
    </div>
    <div class="prf-conv-group">
      <p class="prf-conv-group-title">Reglas de convivencia</p>
      <div class="prf-toggle-grid">
        ${toggleRow("permite_mascotas", "Permite mascotas", p.permite_mascotas)}
        ${toggleRow("permite_fumar", "Permite fumar", p.permite_fumar)}
        ${toggleRow("permite_fiestas", "Permite fiestas/reuniones", p.permite_fiestas)}
        ${toggleRow("permite_visitas", "Permite visitas", p.permite_visitas)}
        ${toggleRow("permite_parejas", "Permite parejas", p.permite_parejas)}
      </div>
    </div>`;
}

function adjuntarListenersConvivencia(cont) {
  cont.querySelectorAll("[data-conv-toggle]").forEach((el) => el.addEventListener("change", () => actualizarPreferencia(el.dataset.convToggle, el.checked, el)));
  cont.querySelectorAll("[data-conv-select]").forEach((el) => el.addEventListener("change", () => actualizarPreferencia(el.dataset.convSelect, el.value || null, el)));
  cont.querySelectorAll("[data-conv-number]").forEach((el) => {
    bloquearTeclasNoEnteras(el);
    el.addEventListener("change", () => actualizarPreferencia(el.dataset.convNumber, el.value ? Number(el.value) : null, el));
  });
  cont.querySelectorAll("[data-conv-text]").forEach((el) => el.addEventListener("change", () => actualizarPreferencia(el.dataset.convText, el.value.trim() || null, el)));
}

function renderConvivencia() {
  const p = usuarioActual.preferenciasConvivencia || {};
  const subtitulo = document.getElementById("convivenciaSubtitle");
  const cont = document.getElementById("convivenciaList");

  subtitulo.textContent = "Cuéntanos tu estilo de vida y, si ofreces un espacio, las reglas de tu hogar";

  cont.innerHTML = `
    <div class="prf-subtabs" id="convSubtabs">
      <button class="prf-subtab active" data-conv-tab="estilo">Mi estilo de vida</button>
      <button class="prf-subtab" data-conv-tab="hogar">Reglas de mi hogar</button>
    </div>
    <div class="prf-conv-panel" id="convPanelEstilo">${bloqueEstiloVida(p)}</div>
    <div class="prf-conv-panel" id="convPanelHogar" hidden>${bloqueReglasHogar(p)}</div>
  `;

  cont.querySelectorAll("[data-conv-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      cont.querySelectorAll("[data-conv-tab]").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById("convPanelEstilo").hidden = btn.dataset.convTab !== "estilo";
      document.getElementById("convPanelHogar").hidden = btn.dataset.convTab !== "hogar";
    });
  });

  adjuntarListenersConvivencia(cont);
}

// ============================================================
// 3) FAVORITOS
// ============================================================
async function cargarFavoritosHabitaciones() {
  const respuesta = await fetch(`${API_BASE}/mis-favoritos/habitaciones`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return [];
  const datos = await respuesta.json();
  return datos.favoritos || [];
}

async function quitarFavoritoHabitacion(id) {
  const respuesta = await fetch(`${API_BASE}/publicaciones/${id}/favorito`, { method: "POST", headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  await renderFavoritos();
}

async function cargarFavoritosRoomies() {
  const respuesta = await fetch(`${API_BASE}/mis-favoritos/roomies`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return [];
  const datos = await respuesta.json();
  return datos.favoritos || [];
}

async function quitarFavoritoRoomie(id) {
  const respuesta = await fetch(`${API_BASE}/roomies/${id}/favorito`, { method: "POST", headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  await renderFavoritos();
}

async function renderFavoritos() {
  const gridHab = document.getElementById("favHabitacionesGrid");
  const gridRoom = document.getElementById("favRoomiesGrid");
  const [favoritosHab, favoritosRoom] = await Promise.all([
    cargarFavoritosHabitaciones(),
    cargarFavoritosRoomies(),
  ]);

  gridHab.innerHTML = favoritosHab.length ? favoritosHab.map((f) => `
    <div class="prf-fav-card">
      <a class="prf-fav-link" href="${esc(appUrl(`/publicacion/${f.id}`))}">
        <div class="prf-fav-img-wrap"><img src="${esc(f.img || "")}" alt="${esc(f.tipo)} ${esc(f.zona)}"/></div>
        <div class="prf-fav-body">
          <div class="prf-fav-title">${esc(f.tipo)}</div>
          <div class="prf-fav-sub">${esc(f.zona)}</div>
          <div class="prf-fav-price">${esc(formatCOP(f.precio))}</div>
        </div>
      </a>
      <button type="button" class="prf-fav-remove" data-remove-hab="${esc(f.id)}" title="Quitar de favoritos">♥</button>
    </div>`).join("") : `<div class="prf-empty">Aún no has guardado habitaciones. <a href="${esc(appUrl('/dashboard'))}">Explora habitaciones →</a></div>`;

  gridRoom.innerHTML = favoritosRoom.length ? favoritosRoom.map((f) => `
    <div class="prf-fav-card">
      <a class="prf-fav-link" href="${esc(appUrl(`/roomie/${f.id}`))}">
        <div class="prf-fav-img-wrap"><img src="${esc(f.img || "")}" alt="${esc(f.nombre)}"/></div>
        <div class="prf-fav-body">
          <div class="prf-fav-title">${esc(f.nombre)}</div>
          <div class="prf-fav-sub">${esc(f.zona)}${esc(f.zona && f.ciudad ? ", " : "")}${esc(f.ciudad || "")}</div>
          <div class="prf-fav-price">${esc(formatCOP(f.presupuesto))}</div>
        </div>
      </a>
      <button type="button" class="prf-fav-remove" data-remove-roomie="${esc(f.id)}" title="Quitar de favoritos">♥</button>
    </div>`).join("") : `<div class="prf-empty">Aún no te has guardado roomies. <a href="${esc(appUrl('/roomies'))}">Explora roomies →</a></div>`;

  gridHab.querySelectorAll("[data-remove-hab]").forEach((btn) => {
    btn.addEventListener("click", (e) => { e.preventDefault(); quitarFavoritoHabitacion(Number(btn.dataset.removeHab)); });
  });
  gridRoom.querySelectorAll("[data-remove-roomie]").forEach((btn) => {
    btn.addEventListener("click", (e) => { e.preventDefault(); quitarFavoritoRoomie(Number(btn.dataset.removeRoomie)); });
  });
}

document.querySelectorAll(".prf-subtab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".prf-subtab").forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    const esHabitaciones = tab.dataset.fav === "habitaciones";
    document.getElementById("favHabitacionesGrid").hidden = !esHabitaciones;
    document.getElementById("favRoomiesGrid").hidden = esHabitaciones;
  });
});

// ============================================================
// MODALES: calificar / reportar (mismo look que la versión original)
// ------------------------------------------------------------
// Generalizados para servir tanto a Reservas (publicaciones) como a
// Mis citas (roomies): reciben el endpoint destino y un callback de
// éxito, en vez de tener el endpoint hardcodeado dentro del modal.
// Los estilos .rr-* viven únicamente en perfil.css (antes también se
// inyectaban aquí por JS en runtime; se quitó esa duplicación para
// tener una sola fuente de verdad).
// ============================================================

/**
 * @param {{titulo: string, sub: string, endpoint: string, onExito: () => void}} opciones
 */
function abrirModalCalificacion({ titulo, sub, endpoint, onExito }) {
  let puntuacionSeleccionada = 0;

  const overlay = document.createElement("div");
  overlay.className = "rr-overlay";
  overlay.innerHTML = `
    <div class="rr-modal">
      <p class="rr-modal-title">${esc(titulo)}</p>
      <p class="rr-modal-sub">${esc(sub)}</p>
      <div class="rr-stars" id="rrStars">
        ${[1, 2, 3, 4, 5].map((n) => `
          <span class="rr-star" data-star="${esc(n)}">
            <span class="rr-star-bg">★</span>
            <span class="rr-star-fill">★</span>
            <span class="rr-star-zone rr-star-zone-half" data-value="${esc(n * 2 - 1)}"></span>
            <span class="rr-star-zone rr-star-zone-full" data-value="${esc(n * 2)}"></span>
          </span>`).join("")}
      </div>
      <p class="rr-rating-value" id="rrRatingValue">Selecciona tu calificación (1 a 10)</p>
      <textarea class="rr-textarea" id="rrComentario" placeholder="Cuéntale a otros usuarios cómo fue tu experiencia..."></textarea>
      <p class="rr-error" id="rrError">Selecciona una calificación y escribe un comentario (mínimo 10 caracteres).</p>
      <div class="rr-buttons">
        <button type="button" class="rr-btn rr-btn-ghost" id="rrCancelar">Cancelar</button>
        <button type="button" class="rr-btn rr-btn-primary" id="rrEnviar">Enviar reseña</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);

  const cerrar = () => overlay.remove();
  overlay.addEventListener("click", (e) => { if (e.target === overlay) cerrar(); });
  document.getElementById("rrCancelar").addEventListener("click", cerrar);

  // Widget de calificación 1-10: 5 estrellas, cada una divisible en
  // mitad izquierda (impar) y mitad derecha (par). rr-star-zone-half
  // y rr-star-zone-full son capas invisibles superpuestas que solo
  // capturan el click; el relleno visual lo pinta pintarEstrellas().
  const estrellas = overlay.querySelectorAll(".rr-star");
  const valorTexto = overlay.querySelector("#rrRatingValue");

  function pintarEstrellas(valor10) {
    estrellas.forEach((estrella, idx) => {
      const n = idx + 1;
      const relleno = estrella.querySelector(".rr-star-fill");
      if (valor10 >= n * 2) relleno.style.width = "100%";
      else if (valor10 === n * 2 - 1) relleno.style.width = "50%";
      else relleno.style.width = "0%";
    });
  }

  overlay.querySelectorAll(".rr-star-zone").forEach((zona) => {
    zona.addEventListener("click", () => {
      puntuacionSeleccionada = Number(zona.dataset.value);
      pintarEstrellas(puntuacionSeleccionada);
      valorTexto.textContent = `${puntuacionSeleccionada} / 10`;
    });
  });

  document.getElementById("rrEnviar").addEventListener("click", async () => {
    const comentario = document.getElementById("rrComentario").value.trim();
    const errorEl = document.getElementById("rrError");
    if (!puntuacionSeleccionada || comentario.length < 10) { errorEl.classList.add("is-visible"); return; }
    errorEl.classList.remove("is-visible");

    const respuesta = await fetch(`${API_BASE}${endpoint}`, {
      method: "POST",
      headers: cabecerasAutenticadas(),
      body: JSON.stringify({ puntuacion: puntuacionSeleccionada, comentario }),
    });
    if (manejarNoAutorizado(respuesta)) return;
    if (!respuesta.ok) { errorEl.textContent = "No se pudo enviar la reseña."; errorEl.classList.add("is-visible"); return; }

    cerrar();
    onExito();
  });
}

function abrirModalReporte({ objetivoTitulo, motivos, onEnviar }) {
  const overlay = document.createElement("div");
  overlay.className = "rr-overlay";
  overlay.innerHTML = `
    <div class="rr-modal">
      <p class="rr-modal-title">Reportar</p>
      <p class="rr-modal-sub">${esc(objetivoTitulo)}</p>
      <label class="rr-label" for="rrMotivo">Motivo</label>
      <select class="rr-select" id="rrMotivo">${motivos.map((m) => `<option value="${esc(m)}">${esc(m)}</option>`).join("")}</select>
      <label class="rr-label" style="margin-top:12px;" for="rrDescripcion">Cuéntanos qué pasó</label>
      <textarea class="rr-textarea" id="rrDescripcion" placeholder="Describe la situación con el mayor detalle posible..."></textarea>
      <p class="rr-error" id="rrReporteError">Escribe una descripción de al menos 15 caracteres.</p>
      <div class="rr-buttons">
        <button type="button" class="rr-btn rr-btn-ghost" id="rrReporteCancelar">Cancelar</button>
        <button type="button" class="rr-btn rr-btn-danger" id="rrReporteEnviar">Enviar reporte</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);

  const cerrar = () => overlay.remove();
  overlay.addEventListener("click", (e) => { if (e.target === overlay) cerrar(); });
  document.getElementById("rrReporteCancelar").addEventListener("click", cerrar);

  document.getElementById("rrReporteEnviar").addEventListener("click", () => {
    const motivo = document.getElementById("rrMotivo").value;
    const descripcion = document.getElementById("rrDescripcion").value.trim();
    const errorEl = document.getElementById("rrReporteError");
    if (descripcion.length < 15) { errorEl.classList.add("is-visible"); return; }
    errorEl.classList.remove("is-visible");
    onEnviar(motivo, descripcion);
    cerrar();
  });
}

// ============================================================
// 4) RESERVAS
// ============================================================
async function renderReservas() {
  const cont = document.getElementById("reservasList");
  const respuesta = await fetch(`${API_BASE}/mis-reservas`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await respuesta.json();
  const reservas = datos.reservas || [];

  if (!reservas.length) {
    cont.innerHTML = `<div class="prf-empty">Aún no has solicitado ninguna visita. <a href="${esc(appUrl('/dashboard'))}">Buscar habitaciones →</a></div>`;
    return;
  }

  cont.innerHTML = reservas.map((r) => `
    <div class="prf-item-card">
      <img class="prf-item-img" src="${esc(r.img || "")}" alt="${esc(r.titulo)}"/>
      <div class="prf-item-body">
        <div class="prf-item-title">${esc(r.titulo)}</div>
        <div class="prf-item-sub">${esc(r.zona)} · ${esc(ETIQUETAS_DURACION[r.duracion] || "")}</div>
        <div class="prf-item-meta">Visita: ${esc(formatFechaCorta(r.fecha_visita))}${esc(r.hora_visita ? ` · ${formatHora12(r.hora_visita)}` : "")} · ${esc(formatCOP(r.monto_total))}</div>
        ${r.estado !== "rechazada" && r.huboEdicion ? `<div class="prf-item-warning">⚠️ El oferente editó esta publicación después de tu solicitud.</div>` : ""}
      </div>
      <div class="prf-item-actions">
        <span class="prf-badge is-${esc(r.estado)}">${esc(ETIQUETAS_BADGE[r.estado] || r.estado)}</span>
        ${r.estado === "aceptada" ? `<a class="prf-item-link" href="${esc(appUrl(`/confirmacion?reservaId=${r.id}`))}">Ver detalle</a>` : ""}
        ${r.estado === "aceptada"
          ? (r.calificada ? `<span class="prf-reviewed-note">★ Ya calificaste</span>` : `<button type="button" class="prf-item-link" data-calificar="${esc(r.id)}">★ Calificar espacio</button>`)
          : ""}
        ${r.estado === "aceptada"
          ? (r.reportada ? `<span class="prf-reviewed-note is-reportado">🚩 Reportado</span>` : `<button type="button" class="prf-item-link is-reportar" data-reportar="${esc(r.id)}">🚩 Reportar</button>`)
          : ""}
      </div>
    </div>`).join("");

  cont.querySelectorAll("[data-calificar]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const r = reservas.find((x) => x.id === Number(btn.dataset.calificar));
      if (!r) return;
      abrirModalCalificacion({
        titulo: "Califica tu experiencia",
        sub: `${r.titulo} · ${r.zona}`,
        endpoint: `/reservas/${r.id}/calificar`,
        onExito: renderReservas,
      });
    });
  });

  cont.querySelectorAll("[data-reportar]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const r = reservas.find((x) => x.id === Number(btn.dataset.reportar));
      if (!r) return;
      abrirModalReporte({
        objetivoTitulo: r.titulo,
        motivos: MOTIVOS_REPORTE_PUBLICACION,
        onEnviar: async (motivo, descripcion) => {
          const resp = await fetch(`${API_BASE}/reservas/${r.id}/reportar`, {
            method: "POST",
            headers: cabecerasAutenticadas(),
            body: JSON.stringify({ motivo, descripcion }),
          });
          if (manejarNoAutorizado(resp)) return;
          renderReservas();
        },
      });
    });
  });
}

// ============================================================
// 5) MIS CITAS
// ============================================================
async function renderCitas() {
  const cont = document.getElementById("citasList");
  const respuesta = await fetch(`${API_BASE}/mis-citas`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await respuesta.json();
  const citas = datos.citas || [];

  if (!citas.length) {
    cont.innerHTML = `<div class="prf-empty">Aún no has agendado citas con roomies. <a href="${esc(appUrl('/roomies'))}">Buscar roomies →</a></div>`;
    return;
  }

  cont.innerHTML = citas.map((c) => `
    <div class="prf-item-card">
      <img class="prf-item-img" src="${esc(c.img || "")}" alt="${esc(c.nombre)}"/>
      <div class="prf-item-body">
        <div class="prf-item-title">${esc(c.nombre)}</div>
        <div class="prf-item-sub">${esc(c.zona)} · ${esc(ETIQUETAS_TIPO_ENCUENTRO[c.tipo_encuentro] || "")} · ${esc(c.lugar_encuentro)}</div>
        <div class="prf-item-meta">Cita: ${esc(formatFechaCorta(c.fecha_cita))}${esc(c.hora_cita ? ` · ${formatHora12(c.hora_cita)}` : "")}</div>
      </div>
      <div class="prf-item-actions">
        <span class="prf-badge is-${esc(c.estado)}">${esc(ETIQUETAS_BADGE[c.estado] || c.estado)}</span>
        ${c.estado === "aceptada" ? `<a class="prf-item-link" href="${esc(appUrl(`/confirmacion-cita?citaId=${c.id}`))}">Ver detalle</a>` : ""}
        ${c.estado === "aceptada"
          ? (c.calificada ? `<span class="prf-reviewed-note">★ Ya calificaste</span>` : `<button type="button" class="prf-item-link" data-calificar-cita="${esc(c.id)}">★ Calificar roomie</button>`)
          : ""}
        ${c.estado === "aceptada"
          ? (c.reportada ? `<span class="prf-reviewed-note is-reportado">🚩 Reportado</span>` : `<button type="button" class="prf-item-link is-reportar" data-reportar-cita="${esc(c.id)}">🚩 Reportar</button>`)
          : ""}
      </div>
    </div>`).join("");

  cont.querySelectorAll("[data-calificar-cita]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const c = citas.find((x) => x.id === Number(btn.dataset.calificarCita));
      if (!c) return;
      abrirModalCalificacion({
        titulo: "Califica a tu roomie",
        sub: `${c.nombre} · ${c.zona}`,
        endpoint: `/citas/${c.id}/calificar`,
        onExito: renderCitas,
      });
    });
  });

  cont.querySelectorAll("[data-reportar-cita]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const c = citas.find((x) => x.id === Number(btn.dataset.reportarCita));
      if (!c) return;
      abrirModalReporte({
        objetivoTitulo: c.nombre,
        motivos: MOTIVOS_REPORTE_ROOMIE,
        onEnviar: async (motivo, descripcion) => {
          const resp = await fetch(`${API_BASE}/citas/${c.id}/reportar`, {
            method: "POST",
            headers: cabecerasAutenticadas(),
            body: JSON.stringify({ motivo, descripcion }),
          });
          if (manejarNoAutorizado(resp)) return;
          renderCitas();
        },
      });
    });
  });
}

// ============================================================
// 6) NOTIFICACIONES
// ============================================================
const NOTIF_ICONOS = {
  reporte_resuelto: { icono: "✓", clase: "is-resuelto" },
  reporte_descartado: { icono: "✕", clase: "is-descartado" },
  reporte_nuevo: { icono: "🚩", clase: "is-info" },
  reserva_nueva: { icono: "🏠", clase: "is-info" },
  reserva_aceptada: { icono: "✓", clase: "is-resuelto" },
  reserva_rechazada: { icono: "✕", clase: "is-descartado" },
  cita_nueva: { icono: "🤝", clase: "is-info" },
  cita_aceptada: { icono: "✓", clase: "is-resuelto" },
  cita_rechazada: { icono: "✕", clase: "is-descartado" },
  mensaje_contacto_nuevo: { icono: "✉️", clase: "is-info" },
};

async function renderNotificaciones() {
  const cont = document.getElementById("notificacionesList");
  const respuesta = await fetch(`${API_BASE}/notificaciones`, { headers: cabecerasAutenticadas(false) });
  if (manejarNoAutorizado(respuesta)) return;
  const datos = await respuesta.json();
  const notificaciones = datos.notificaciones || [];

  actualizarBadgeSidebar(notificaciones);

  if (!notificaciones.length) {
    cont.innerHTML = `<div class="prf-empty">Aún no tienes notificaciones. Cuando reportes algo, o recibas una solicitud de reserva o cita, te avisaremos aquí.</div>`;
    return;
  }

  cont.innerHTML = notificaciones.map((n) => {
    const { icono, clase } = NOTIF_ICONOS[n.tipo] || { icono: "•", clase: "is-info" };
    const contenido = `
        <span class="prf-notif-icon ${esc(clase)}">${esc(icono)}</span>
        <div class="prf-notif-body">
          <p class="prf-notif-mensaje">${esc(n.mensaje)}</p>
          <p class="prf-notif-fecha">${esc(formatFechaHora(n.fecha))}</p>
        </div>`;
    return n.link
      ? `<a class="prf-notif-card ${esc(n.leida ? "" : "is-unread")}" href="${esc(n.link)}">${contenido}</a>`
      : `<div class="prf-notif-card ${esc(n.leida ? "" : "is-unread")}">${contenido}</div>`;
  }).join("");
}

function actualizarBadgeSidebar(notificaciones) {
  const noLeidas = notificaciones.filter((n) => !n.leida).length;
  const badge = document.getElementById("prfNotifBadge");
  badge.hidden = noLeidas === 0;
  badge.textContent = noLeidas > 9 ? "9+" : noLeidas;
}

async function marcarNotificacionesLeidas() {
  await fetch(`${API_BASE}/notificaciones/marcar-leidas`, { method: "POST", headers: cabecerasAutenticadas(false) });
  await renderNotificaciones();
  window.RoommatchNav.actualizarBadgeNotificaciones();
}

// ---------- INICIALIZACIÓN ----------
renderDatosPersonales();
renderConvivencia();
renderFavoritos();
renderReservas();
renderCitas();
renderNotificaciones();
activarPanelPorHash();
