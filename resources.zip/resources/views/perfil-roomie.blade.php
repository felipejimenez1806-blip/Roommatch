@extends('layouts.app')

@section('title', 'Roommatch – Perfil de roomie')

@push('css')
@vite('resources/css/pages/perfil-roomie.css')
@endpush

@section('content')

<div class="rp-page" id="rpPage" data-id="{{ $id }}">
  <!-- Todo el contenido se genera dinámicamente desde perfil-roomie.js -->
</div>

@endsection

@push('js')
@vite('resources/js/pages/perfil-roomie.js')
@endpush
