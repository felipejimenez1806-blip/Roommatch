<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\CambiarRolRequest;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegistroRequest;
use App\Http\Requests\SeleccionarRolRequest;
use App\Models\Rol;
use App\Models\Usuario;
use App\Services\SesionUsuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;

class AuthController extends Controller
{
    private const MAX_INTENTOS_LOGIN = 5;

    /**
     * POST /api/registro
     * Equivalente al submit de signup.js, pero validando y
     * guardando en MySQL real en vez de localStorage.
     *
     * El rol ya NO se recibe del formulario: todo registro público nace
     * con el rol 'cliente' únicamente (asignado aquí mismo tras crear la
     * fila en usuario). 'admin' solo se asigna manualmente en BD o desde
     * el panel de administración (Fase 3).
     *
     * La sesión queda abierta al terminar el registro (cookie de sesión de
     * Laravel, ver App\Services\SesionUsuario): el cuerpo ya no trae token.
     *
     * terminos_aceptados_en: RegistroRequest ya exige que el checkbox
     * llegue marcado (acepta_terminos => accepted), así que si la petición
     * pasó la validación, aceptó los términos justo ahora.
     */
    public function registro(RegistroRequest $request)
    {
        $datos = $request->validated();

        $usuario = DB::transaction(function () use ($datos) {
            $usuario = Usuario::create([
                'nombre_completo' => $datos['nombre'],
                'correo' => $datos['email'],
                'telefono' => $datos['telefono'],
                'direccion' => $datos['direccion'],
                'contrasena' => Hash::make($datos['password']),
                'proveedor' => 'local',
                'terminos_aceptados_en' => now(),
            ]);

            $rolCliente = Rol::where('nombre', 'cliente')->firstOrFail();

            $usuario->roles()->attach($rolCliente->id_rol, [
                'fecha_asignacion' => now(),
                'asignado_por' => null,
            ]);

            return $usuario;
        });

        $usuario->load('roles');
        $emision = SesionUsuario::iniciar($request, $usuario);

        return response()->json(array_merge([
            'mensaje' => '¡Cuenta creada con éxito!',
            'usuario' => $usuario->paraFrontend(),
        ], $emision), 201);
    }

    /**
     * POST /api/login
     * Equivalente al submit de login.js. No filtra por 'proveedor':
     * una cuenta que empezó local y luego se vinculó con Google/Facebook
     * (ver SocialAuthController) sigue pudiendo entrar aquí con su
     * contraseña mientras 'contrasena' no sea null.
     *
     * Bloqueo automático: tras MAX_INTENTOS_LOGIN contraseñas incorrectas
     * seguidas, la cuenta se marca bloqueado = true (mismo campo que usa
     * el panel de admin), y solo un admin puede desbloquearla desde ahí
     * (AdminUsuarioController@desbloquear). El mensaje de error se
     * mantiene genérico mientras la cuenta no esté bloqueada, para no
     * revelar por intentos si un correo existe o no en la base de datos.
     *
     * Selección de rol: ver SesionUsuario::iniciar().
     */
    public function login(LoginRequest $request)
    {
        $usuario = Usuario::where('correo', $request->email)->first();

        // Superadmin: NO se bloquea automáticamente. Solo otro superadmin puede
        // bloquear esa cuenta; con el bloqueo automático cualquiera podría
        // dejarla fuera escribiendo 5 contraseñas erróneas (y, si es la única,
        // nadie podría desbloquearla). En su lugar: límite temporal de intentos
        // por correo + IP (así quien ataca solo se limita a sí mismo).
        $claveSuperadmin = null;
        if ($usuario && $usuario->esSuperadmin()) {
            $claveSuperadmin = 'login-superadmin:'.mb_strtolower($usuario->correo).'|'.$request->ip();
            if (RateLimiter::tooManyAttempts($claveSuperadmin, self::MAX_INTENTOS_LOGIN)) {
                $minutos = (int) ceil(RateLimiter::availableIn($claveSuperadmin) / 60);

                return response()->json([
                    'mensaje' => "Demasiados intentos fallidos. Intenta de nuevo en {$minutos} minuto(s).",
                ], 429);
            }
        }

        $credencialesValidas = $usuario
            && $usuario->contrasena
            && Hash::check($request->password, $usuario->contrasena);

        if (! $credencialesValidas) {
            // Solo contamos el intento fallido si es una cuenta local real
            // y todavía no está bloqueada (para no seguir incrementando
            // de más una vez ya bloqueada).
            if ($claveSuperadmin) {
                RateLimiter::hit($claveSuperadmin, 900);
            } elseif ($usuario && $usuario->contrasena && ! $usuario->bloqueado) {
                $usuario->increment('intentos_fallidos');

                if ($usuario->intentos_fallidos >= self::MAX_INTENTOS_LOGIN) {
                    $usuario->update([
                        'bloqueado' => true,
                        'bloqueado_motivo' => 'Bloqueo automático por demasiados intentos fallidos de inicio de sesión.',
                        'bloqueado_fecha' => now(),
                    ]);
                }
            }

            return response()->json([
                'mensaje' => 'Datos incorrectos vuelva a intentar.',
            ], 401);
        }

        if ($usuario->bloqueado) {
            return response()->json([
                'mensaje' => $usuario->bloqueado_motivo
                    ? "Tu cuenta fue bloqueada: {$usuario->bloqueado_motivo}"
                    : 'Tu cuenta ha sido bloqueada. Contacta al soporte.',
            ], 403);
        }

        if ($claveSuperadmin) {
            RateLimiter::clear($claveSuperadmin);
        }

        // Login correcto: reiniciamos el contador si venía con intentos previos.
        if ($usuario->intentos_fallidos > 0) {
            $usuario->update(['intentos_fallidos' => 0]);
        }

        $usuario->load('roles');
        $emision = SesionUsuario::iniciar($request, $usuario);

        return response()->json(array_merge([
            'mensaje' => '¡Bienvenido a RoomMatch!',
            'usuario' => $usuario->paraFrontend(),
        ], $emision));
    }

    /**
     * POST /api/seleccionar-rol
     * Segundo paso del login cuando la cuenta tiene más de un rol: el
     * usuario ya puso bien su contraseña (login() o el login social lo
     * dejaron "pendiente" en la sesión, sin autenticar) y aquí elige con
     * cuál entrar. Protegido por el middleware RequiereSeleccionRol, que
     * es quien resuelve el usuario pendiente.
     *
     * No vuelve a pedir contraseña: el usuario la acaba de escribir hace
     * segundos para llegar aquí desde login(). Comparar con cambiarRol(),
     * que sí la vuelve a pedir para pasar a admin porque puede ocurrir
     * mucho después, en medio de una sesión ya abierta.
     */
    public function seleccionarRol(SeleccionarRolRequest $request)
    {
        $usuario = $request->attributes->get('usuario_pendiente');
        $rol = $request->validated('rol');

        if (! $usuario->tieneRol($rol)) {
            abort(403, 'No tienes asignado ese rol.');
        }

        SesionUsuario::abrir($request, $usuario, $rol);

        return response()->json([
            'mensaje' => "Ingresaste como {$rol}.",
            'rolActivo' => $rol,
            'usuario' => $usuario->paraFrontend(),
        ]);
    }

    /**
     * POST /api/cambiar-rol
     * Permite, desde una sesión ya abierta, cambiar entre los roles que
     * el usuario tenga asignados. Exige reingresar la contraseña cuando el
     * rol destino es 'admin' o 'moderador' (ver CambiarRolRequest).
     */
    public function cambiarRol(CambiarRolRequest $request)
    {
        $usuario = $request->user();
        $rolDestino = $request->validated('rol');

        if ($usuario->esSuperadmin()) {
            abort(403, 'Una cuenta superadmin solo puede ejercer el rol de administrador.');
        }

        if (! $usuario->tieneRol($rolDestino)) {
            abort(403, 'No tienes asignado ese rol.');
        }

        if (in_array($rolDestino, ['admin', 'moderador'], true)) {
            $contrasenaValida = $usuario->contrasena
                && Hash::check($request->validated('password'), $usuario->contrasena);

            if (! $contrasenaValida) {
                return response()->json([
                    'mensaje' => 'Contraseña incorrecta.',
                ], 401);
            }
        }

        // El rol activo vive en la sesión. Se regenera el id de sesión
        // porque cambia el nivel de privilegio (sobre todo al pasar a admin).
        $request->session()->put(SesionUsuario::ROL_ACTIVO, $rolDestino);
        $request->session()->regenerate();

        return response()->json([
            'mensaje' => "Ahora estás como {$rolDestino}.",
            'rolActivo' => $rolDestino,
            'usuario' => $usuario->paraFrontend(),
        ]);
    }

    /**
     * POST /api/agregar-rol-cliente
     * Autoservicio: cualquier usuario autenticado (en la práctica, un
     * admin creado sin rol cliente vía crearAdministrador()) puede
     * agregarse el rol 'cliente' a sí mismo, sin pedir contraseña ni
     * aprobación de otro admin — a diferencia de volverse admin, esto
     * NO es una elevación de privilegios, así que no necesita el mismo
     * rigor. No quita ningún rol que ya tenga (un admin que hace esto
     * sigue siendo admin, ahora también cliente).
     */
    public function agregarRolCliente(Request $request)
    {
        $usuario = $request->user();

        if ($usuario->esSuperadmin()) {
            abort(403, 'Una cuenta superadmin solo puede ejercer el rol de administrador.');
        }

        if ($usuario->tieneRol('cliente')) {
            return response()->json([
                'mensaje' => 'Ya tienes el rol de cliente.',
            ], 409);
        }

        $rolCliente = Rol::where('nombre', 'cliente')->firstOrFail();

        $usuario->roles()->attach($rolCliente->id_rol, [
            'fecha_asignacion' => now(),
            'asignado_por' => $usuario->id_usuario,
        ]);

        $usuario->load('roles');

        return response()->json([
            'mensaje' => 'Ahora también tienes el rol de cliente.',
            'usuario' => $usuario->paraFrontend(),
        ]);
    }

    /**
     * POST /api/logout
     * Cierra la sesión (cookie) y rota el token CSRF.
     */
    public function logout(Request $request)
    {
        SesionUsuario::cerrar($request);

        return response()->json(['mensaje' => 'Sesión cerrada correctamente.']);
    }

    /**
     * GET /api/usuario
     * Devuelve el usuario autenticado actual junto con el rol activo de la
     * sesión. Además de servir para restaurar datos, el frontend lo usa
     * como "ping" para mantener viva la sesión mientras hay actividad (ver
     * renovarSesion() en core/auth.js).
     */
    public function usuarioActual(Request $request)
    {
        $usuario = $request->user()->load('roles');

        return response()->json([
            'usuario' => $usuario->paraFrontend(),
            'rolActivo' => SesionUsuario::rolActivo(),
        ]);
    }
}
