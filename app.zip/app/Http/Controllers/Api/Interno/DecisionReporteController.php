<?php

namespace App\Http\Controllers\Api\Interno;

use App\Http\Controllers\Controller;
use App\Models\AccionModeracion;
use App\Models\Notificacion;
use App\Models\Reporte;
use App\Services\ModeracionContenido;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * POST /api/interno/reportes/decision
 *
 * Endpoint interno: lo llama el servicio de reportes (Spring) cuando su personal
 * cierra un reporte. Va protegido por VerificarServiceKey (header X-Service-Key),
 * no por sesión de usuario.
 *
 * Aplica en RoomMatch la decisión del servicio:
 *   - accion BAJAR_CONTENIDO  -> baja la publicación o el perfil de roomie reportado
 *   - accion BLOQUEAR_USUARIO -> bloquea la cuenta del usuario reportado
 *   - accion SIN_ACCION       -> no toca nada
 * actualiza la fila espejo, avisa a quien reportó y deja la auditoría.
 *
 * Es idempotente: si el reporte ya estaba cerrado responde 200 sin repetir nada,
 * así el servicio puede reintentar sin riesgo.
 */
class DecisionReporteController extends Controller
{
    private const ESTADO_LOCAL = [
        'PENDIENTE' => 'pendiente',
        'EN_REVISION' => 'pendiente',
        'ESCALADO' => 'escalado',
        'RESUELTO' => 'resuelto',
        'DESCARTADO' => 'descartado',
    ];

    public function __invoke(Request $request, ModeracionContenido $moderacion): JsonResponse
    {
        $datos = $request->validate([
            'idReporteServicio' => ['required', 'integer'],
            'estado' => ['required', 'in:RESUELTO,DESCARTADO'],
            'accion' => ['required', 'in:SIN_ACCION,BAJAR_CONTENIDO,BLOQUEAR_USUARIO'],
            'idReportado' => ['nullable', 'integer', 'required_if:accion,BLOQUEAR_USUARIO'],
            'nota' => ['nullable', 'string', 'max:500'],
            'gestionadoPor' => ['nullable', 'string', 'max:150'],
        ]);

        $reporte = Reporte::where('id_reporte_servicio', $datos['idReporteServicio'])->first();

        if (! $reporte) {
            return response()->json(['mensaje' => 'No existe un reporte local con ese id de servicio.'], 404);
        }

        if (in_array($reporte->estado_reporte, ['resuelto', 'descartado'], true)) {
            return response()->json(['ok' => true, 'yaAplicado' => true]);
        }

        $resuelto = $datos['estado'] === 'RESUELTO';
        $accionAplicada = 'ninguna';

        try {
            DB::transaction(function () use ($datos, $reporte, $moderacion, $resuelto, &$accionAplicada) {
                if ($resuelto) {
                    $accionAplicada = $this->aplicarAccion($datos, $reporte, $moderacion);
                }

                $reporte->update([
                    'estado_reporte' => self::ESTADO_LOCAL[$datos['estado']],
                    'fecha_gestion' => now(),
                ]);

                AccionModeracion::create([
                    'id_usuario' => null,
                    'rol_activo' => 'servicio_reportes',
                    'accion' => $resuelto ? 'reporte_resuelto' : 'reporte_descartado',
                    'entidad_tipo' => 'reporte',
                    'entidad_id' => $reporte->id_reporte,
                    'entidad_titulo' => $reporte->objetivo_titulo !== null ? mb_substr($reporte->objetivo_titulo, 0, 255) : null,
                    'detalle' => [
                        'tipo' => $reporte->tipo,
                        'motivo' => $reporte->motivo,
                        'accion_aplicada' => $accionAplicada,
                        'gestionado_por' => $datos['gestionadoPor'] ?? null,
                        'nota' => $datos['nota'] ?? null,
                        'id_reporte_servicio' => $reporte->id_reporte_servicio,
                    ],
                    'fecha' => now(),
                ]);
            });
        } catch (DomainException $e) {
            // La decisión no se pudo aplicar (p. ej. cuenta del equipo): nada
            // cambió y el servicio deja el reporte abierto y muestra el mensaje.
            return response()->json(['mensaje' => $e->getMessage()], 422);
        }

        $this->notificarReportante($reporte, $resuelto);

        return response()->json(['ok' => true, 'accionAplicada' => $accionAplicada]);
    }

    /** @return string  lo que realmente se hizo (para la auditoría) */
    private function aplicarAccion(array $datos, Reporte $reporte, ModeracionContenido $moderacion): string
    {
        switch ($datos['accion']) {
            case 'BAJAR_CONTENIDO':
                if ($reporte->tipo === 'publicacion' && $reporte->id_publicacion) {
                    return $moderacion->bajarPublicacion($reporte->id_publicacion) ? 'publicacion_bajada' : 'publicacion_ya_no_existe';
                }
                if ($reporte->tipo === 'persona' && $reporte->id_persona) {
                    return $moderacion->bajarPersona($reporte->id_persona) ? 'persona_bajada' : 'persona_ya_no_existe';
                }

                return 'sin_contenido_que_bajar';

            case 'BLOQUEAR_USUARIO':
                $usuario = $moderacion->bloquearUsuario((int) $datos['idReportado'], $reporte->motivo);

                return $usuario ? 'usuario_bloqueado' : 'usuario_ya_no_existe';

            default:
                return 'ninguna';
        }
    }

    private function notificarReportante(Reporte $reporte, bool $resuelto): void
    {
        if (! $reporte->id_usuario_reporta) {
            return;
        }

        Notificacion::create([
            'id_usuario' => $reporte->id_usuario_reporta,
            'tipo' => $resuelto ? 'reporte_resuelto' : 'reporte_descartado',
            'mensaje' => $resuelto
                ? "Revisamos tu reporte sobre \"{$reporte->objetivo_titulo}\" y tomamos una acción al respecto. Gracias por ayudarnos a mantener la comunidad segura."
                : "Revisamos tu reporte sobre \"{$reporte->objetivo_titulo}\" y no encontramos elementos suficientes para tomar una acción. Gracias por ayudarnos a mantener la comunidad segura.",
            'objetivo_titulo' => $reporte->objetivo_titulo,
            'leida' => false,
        ]);
    }
}
