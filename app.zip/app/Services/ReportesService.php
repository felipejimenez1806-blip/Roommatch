<?php

namespace App\Services;

use App\Exceptions\ReportesNoDisponibleException;
use App\Models\PersonaRoomie;
use App\Models\Publicacion;
use App\Models\Reporte;
use App\Models\Usuario;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

/**
 * Envía los reportes al servicio de reportes y moderación (Spring Boot) y deja
 * en Laravel un registro "espejo" (tabla reporte, con id_reporte_servicio) para
 * que quien reportó vea "Reportado" y reciba la notificación cuando el equipo
 * decida. La gestión del reporte (estados, moderadores, escalamiento) vive en
 * el servicio.
 *
 * Orden: primero se envía al servicio y SOLO si lo acepta se crea la fila local.
 * Si el servicio está caído no se guarda nada (ni aquí ni allá) y se lanza
 * ReportesNoDisponibleException (503 con mensaje claro): la persona sabe que su
 * reporte no se envió y puede reintentarlo.
 *
 * Reintentos: se repite solo ante fallos transitorios (sin conexión, tiempo
 * agotado, 5xx). Un 4xx no se reintenta (repetirlo daría lo mismo). Como un
 * reintento puede llegar cuando el primer intento sí se procesó (se cayó la
 * respuesta), todos los intentos llevan la MISMA 'referencia': el servicio la
 * usa como clave de idempotencia y no crea el reporte dos veces.
 */
class ReportesService
{
    public function reportarPublicacion(Usuario $reportante, Publicacion $publicacion, string $motivo, string $descripcion): Reporte
    {
        $propietario = $publicacion->propietario;

        return $this->registrar($reportante, [
            'tipo' => 'PUBLICACION',
            'idObjetivo' => $publicacion->id_publicacion,
            'idReportado' => $publicacion->id_usuario,
            'nombreReportado' => $propietario?->nombre_completo,
            'telefonoReportado' => $propietario?->telefono,
            'tituloObjetivo' => $publicacion->titulo,
        ], [
            'tipo' => 'publicacion',
            'id_publicacion' => $publicacion->id_publicacion,
            'objetivo_titulo' => $publicacion->titulo,
        ], $motivo, $descripcion);
    }

    public function reportarRoomie(Usuario $reportante, PersonaRoomie $persona, string $motivo, string $descripcion): Reporte
    {
        $persona->loadMissing('usuario');
        $duenio = $persona->usuario;
        $nombre = $duenio?->nombre_completo;

        return $this->registrar($reportante, [
            'tipo' => 'ROOMIE',
            'idObjetivo' => $persona->id_persona,
            'idReportado' => $persona->id_usuario,
            'nombreReportado' => $nombre,
            'telefonoReportado' => $duenio?->telefono ?: $persona->telefono,
            'tituloObjetivo' => $nombre,
        ], [
            'tipo' => 'persona',
            'id_persona' => $persona->id_persona,
            'objetivo_titulo' => $nombre,
        ], $motivo, $descripcion);
    }

    // ------------------------------------------------------------------

    /**
     * @param  array  $objetivoRemoto  campos del reporte que dependen del objetivo (formato del servicio)
     * @param  array  $objetivoLocal   campos equivalentes para la fila espejo (formato de la tabla reporte)
     */
    private function registrar(Usuario $reportante, array $objetivoRemoto, array $objetivoLocal, string $motivo, string $descripcion): Reporte
    {
        $payload = $objetivoRemoto + [
            'referencia' => (string) Str::uuid(),
            'idReportante' => $reportante->id_usuario,
            'nombreReportante' => $reportante->nombre_completo,
            'telefonoReportante' => $reportante->telefono,
            'motivo' => $motivo,
            'descripcion' => $descripcion,
        ];

        $respuesta = $this->enviar($payload);

        return Reporte::firstOrCreate(
            ['id_reporte_servicio' => $respuesta['id']],
            $objetivoLocal + [
                'id_usuario_reporta' => $reportante->id_usuario,
                'motivo' => $motivo,
                'descripcion' => $descripcion,
            ]
        );
    }

    /** POST /api/reportes con reintentos. Devuelve el JSON de la respuesta (trae 'id'). */
    private function enviar(array $payload): array
    {
        $clave = (string) config('reportes.clave');

        if ($clave === '') {
            Log::error('Reportes: ROOMMATCH_SERVICE_KEY no está configurada en el .env de Laravel.');
            throw new ReportesNoDisponibleException('Clave de servicio no configurada.');
        }

        try {
            $respuesta = Http::baseUrl(config('reportes.url'))
                ->withHeaders(['X-Service-Key' => $clave])
                ->acceptJson()
                ->asJson()
                ->timeout(config('reportes.timeout'))
                ->retry(
                    config('reportes.intentos'),
                    config('reportes.espera_ms'),
                    // Solo fallos transitorios: sin conexión o 5xx.
                    fn (Throwable $e) => $e instanceof ConnectionException
                        || ($e instanceof RequestException && $e->response->serverError()),
                    throw: false,
                )
                ->post('/api/reportes', $payload);
        } catch (ConnectionException $e) {
            Log::warning('Reportes: el servicio no respondió tras los reintentos.', ['error' => $e->getMessage()]);
            throw new ReportesNoDisponibleException($e->getMessage());
        }

        if ($respuesta->successful() && is_int($respuesta->json('id'))) {
            return $respuesta->json();
        }

        // 5xx tras los reintentos, o 401/403 (clave distinta entre servicios): el
        // usuario no puede hacer nada, así que se le dice que reintente luego y
        // el detalle queda en el log para quien opera el sistema.
        Log::error('Reportes: el servicio rechazó o falló al recibir el reporte.', [
            'status' => $respuesta->status(),
            'cuerpo' => mb_substr($respuesta->body(), 0, 500),
        ]);

        throw new ReportesNoDisponibleException("HTTP {$respuesta->status()}");
    }
}
