<?php

namespace App\Services;

use App\Models\Notificacion;
use App\Models\PersonaRoomie;
use App\Models\Publicacion;
use App\Models\Usuario;
use DomainException;

/**
 * Acciones de moderación sobre el contenido de RoomMatch. Las usa el endpoint
 * interno que llama el servicio de reportes cuando el equipo decide.
 *
 * NOTA: Api\Admin\ReporteController tiene copias de bajarPublicacion() y
 * bajarPersona() (eliminarPublicacionReportada / eliminarPersonaReportada),
 * que se dejaron intactas para no tocar el flujo antiguo. Cuando se retire
 * ese flujo, que use esta clase.
 */
class ModeracionContenido
{
    /**
     * Baja (soft delete) la publicación. Se carga el modelo para rechazar a mano
     * las reservas pendientes (con aviso): con SoftDeletes ya no se dispara el
     * ON DELETE CASCADE. Si la publicación ya no existe no hace nada.
     */
    public function bajarPublicacion(int $idPublicacion): bool
    {
        $publicacion = Publicacion::find($idPublicacion);

        if (! $publicacion) {
            return false;
        }

        foreach ($publicacion->reservas()->where('estado_reserva', 'pendiente')->get() as $reserva) {
            $reserva->update(['estado_reserva' => 'rechazada', 'fecha_respuesta' => now()]);

            Notificacion::create([
                'id_usuario' => $reserva->id_usuario,
                'tipo' => 'reserva_rechazada',
                'mensaje' => "\"{$publicacion->titulo}\" fue eliminada tras revisar un reporte, así que tu solicitud de reserva fue rechazada automáticamente.",
                'objetivo_titulo' => $publicacion->titulo,
                'link' => '/perfil#panelReservas',
                'leida' => false,
            ]);
        }

        $publicacion->delete();

        return true;
    }

    /** Baja (soft delete) el perfil de roomie, con el mismo tratamiento de las citas pendientes. */
    public function bajarPersona(int $idPersona): bool
    {
        $persona = PersonaRoomie::with('usuario')->find($idPersona);

        if (! $persona) {
            return false;
        }

        foreach ($persona->citas()->where('estado_cita', 'pendiente')->get() as $cita) {
            $cita->update(['estado_cita' => 'rechazada', 'fecha_respuesta' => now()]);

            Notificacion::create([
                'id_usuario' => $cita->id_usuario,
                'tipo' => 'cita_rechazada',
                'mensaje' => 'Este perfil de roomie fue eliminado tras revisar un reporte, así que tu solicitud de cita fue rechazada automáticamente.',
                'objetivo_titulo' => $persona->usuario->nombre_completo ?? 'Perfil de roomie',
                'link' => '/perfil#panelCitas',
                'leida' => false,
            ]);
        }

        $persona->delete();

        return true;
    }

    /**
     * Bloquea una cuenta de cliente y cierra sus sesiones. Nunca bloquea cuentas
     * del equipo (admin o moderador): eso se gestiona dentro de Laravel.
     *
     * @throws DomainException con un mensaje apto para mostrar al personal
     */
    public function bloquearUsuario(int $idUsuario, string $motivo): ?Usuario
    {
        $usuario = Usuario::with('roles')->find($idUsuario);

        if (! $usuario) {
            return null;
        }

        if ($usuario->esAdmin() || $usuario->tieneRol('moderador')) {
            throw new DomainException('La cuenta reportada es del equipo de RoomMatch y no se puede bloquear desde el servicio de reportes.');
        }

        if (! $usuario->bloqueado) {
            Usuario::whereKey($usuario->id_usuario)->update([
                'bloqueado' => true,
                'bloqueado_motivo' => mb_substr("Reporte: {$motivo}", 0, 255),
                'bloqueado_fecha' => now(),
            ]);

            SesionUsuario::cerrarSesionesDe($usuario);
        }

        return $usuario;
    }
}
