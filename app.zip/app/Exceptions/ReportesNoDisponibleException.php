<?php

namespace App\Exceptions;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use RuntimeException;

/**
 * El servicio de reportes no respondió (caído, sin red, tiempo agotado, error 5xx
 * o clave mal configurada) incluso después de los reintentos.
 *
 * Se renderiza sola como 503 con un mensaje claro para el usuario, así los
 * controladores no tienen que capturarla. El detalle técnico ya quedó en el
 * log desde ReportesService, por eso report() devuelve false (no duplica).
 */
class ReportesNoDisponibleException extends RuntimeException
{
    public const MENSAJE = 'El servicio de reportes no está disponible en este momento, así que tu reporte NO se envió. Inténtalo de nuevo en unos minutos.';

    public function __construct(string $detalleTecnico = '')
    {
        parent::__construct($detalleTecnico !== '' ? $detalleTecnico : self::MENSAJE);
    }

    public function report(): bool
    {
        return false;
    }

    public function render(Request $request): JsonResponse
    {
        return response()->json(['mensaje' => self::MENSAJE], 503);
    }
}
