<?php

/*
|--------------------------------------------------------------------------
| Servicio de reportes y moderación (Spring Boot)
|--------------------------------------------------------------------------
| Se lee desde aquí (y no con env() en el código) para que siga funcionando
| con `php artisan config:cache`.
|
| .env de Laravel:
|   REPORTES_URL=http://localhost:8081
|   ROOMMATCH_SERVICE_KEY=<la misma clave larga y aleatoria que usa Spring>
*/
return [
    // URL base del servicio de reportes.
    'url' => rtrim((string) env('REPORTES_URL', 'http://localhost:8081'), '/'),

    // Clave compartida entre servicios (header X-Service-Key). Sirve en los dos
    // sentidos: Laravel -> Spring (enviar reporte) y Spring -> Laravel (decisión).
    'clave' => env('ROOMMATCH_SERVICE_KEY'),

    // Segundos máximos de espera por intento.
    'timeout' => (int) env('REPORTES_TIMEOUT', 5),

    // Intentos totales (1 + reintentos) y espera entre ellos, en milisegundos.
    'intentos' => (int) env('REPORTES_INTENTOS', 3),
    'espera_ms' => (int) env('REPORTES_ESPERA_MS', 400),
];
